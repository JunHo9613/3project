﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20210616
{
    public partial class Form1 : Form
    {
        private bool Left = true;
        private bool Right = true;
        private bool Up = true;
        private bool Down = true;

        public Form1()
        {
            InitializeComponent();

            this.BackColor = Color.Black;
            this.Paint += Form1_Paint;
            this.KeyUp += Form1_KeyUp;
            this.KeyDown += Form1_KeyDown;
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            Keys key = e.KeyCode;
            switch (key)
            {
                case Keys.Left:
                    Left = true;
                    break;
                case Keys.Right:
                    Right = true;
                    break;
                case Keys.Up:
                    Up = true;
                    break;
                case Keys.Down:
                    Down = true;
                    break;
            }

            Invalidate();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            Keys key = e.KeyCode;
            switch (key)
            {
                case Keys.Left:
                    Left = false;
                    break;
                case Keys.Right:
                    Right = false;
                    break;
                case Keys.Up:
                    Up = false;
                    break;
                case Keys.Down:
                    Down = false;
                    break;
            }

            Invalidate();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Gold, 5);
            g.DrawRectangle(pen, 120, 10, 50, 90);
            g.DrawRectangle(pen, 70, 100, 50, 90);
            g.DrawRectangle(pen, 170, 100, 50, 90);
            g.DrawRectangle(pen, 120, 190, 50, 90);

            if (Left == false) g.FillRectangle(Brushes.Red, 70, 100, 50, 90);

            if (Right == false) g.FillRectangle(Brushes.Red, 170, 100, 50, 90);

            if (Up == false) g.FillRectangle(Brushes.Red, 120, 10, 50, 90);                        
                                    
            if (Down == false) g.FillRectangle(Brushes.Red, 120, 190, 50, 90);

        }
    }
}

