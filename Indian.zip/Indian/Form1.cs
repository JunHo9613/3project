﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Indian
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        Socket clientSocket;
        IPEndPoint ipep;

        Thread tRecv;
        int my_Money = 20000;
        string my_Card = "C|";
        string value;
        int enemy_Card;
        bool isRecv;
        bool isTurn = false;
        int i = 0;
        int betting;
        bool win;
        int winner;
        bool gameover;
        bool call;
        IndianStart indian = null;
        string[] card = new string[] {"../../../에이스.jpg","../../../2.jpg", "../../../3.jpg", "../../../4.jpg", "../../../5.jpg", "../../../6.jpg"
                                     ,"../../../7.jpg","../../../8.jpg","../../../9.jpg","../../../10.jpg","../../../J.jpg","../../../Q.jpg"
                                     ,"../../../K.jpg","../../../Joker2.jpg"};
        public Form1()
        {
            InitializeComponent();
            this.FormClosed += Form1_FormClosed;
            this.Paint += Form1_Paint;
            this.nud_stakes.Minimum = 2000;
            this.nud_stakes.Value = 2000;
            this.nud_stakes.Maximum = my_Money;
            this.Shown += Form1_Shown;
            //this.KeyDown += Form1_KeyDown;
        }

        /*private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                sendValue("CL|");
            }
        }
*/
        private void Form1_Shown(object sender, EventArgs e)
        {
            indian = new IndianStart();
            indian.Owner = this;
            indian.ShowDialog();
            // 소켓 생성(휴대폰 구매)
            clientSocket = new(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            string ip = "127.0.0.1";
            int port = 9000;

            this.ipep = new IPEndPoint(IPAddress.Parse(ip), port);

            this.clientSocket.Connect(this.ipep);

            // 서버와 송/수신 스레드 생성
            this.isRecv = true;
            tRecv = new Thread(new ThreadStart(ThreadRecv));
            tRecv.Start();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Font f;
            if (gameover)
            {
                btn_All_In.Enabled = false;
                btn_Betting.Enabled = false;
                btn_Call.Enabled = false;
                btn_Fold.Enabled = false;
                btn_Raise.Enabled = false;
                sendValue("CL|");
            }

            Image image_card = Image.FromFile(card[enemy_Card]);
            e.Graphics.DrawImage(image_card, 380, 60);
            this.tb_Money.Text = $"{my_Money}";
            f = new("돋움", 15);
            if (isTurn)
            {
                e.Graphics.DrawString($"Player {i + 1}의 차례입니다.", f, Brushes.Black, 680, 100);
            }
            if (win)
            {
                if (winner == 2)
                {
                    f = new("돋움", 30);
                    e.Graphics.DrawString($"무승부입니다!", f, Brushes.Gold, 240, 200);
                    gameover = true;
                }
                else
                {
                    f = new("돋움", 30);
                    e.Graphics.DrawString($"승자는 Player {winner + 1}입니다!", f, Brushes.Gold, 240, 200);
                    gameover = true;
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                this.isRecv = false;
                // 클라이언트 소켓 객체가 존재하고, 연결되어있다면
                if (this.clientSocket != null && this.clientSocket.Connected)
                {
                    this.clientSocket.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Exception: {ex.Message}");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.btn_Betting.Enabled = true;
            this.btn_Call.Enabled = false;
            this.btn_Fold.Enabled = true;
            this.btn_Raise.Enabled = false;
            this.btn_All_In.Enabled = false;
        }

        private void ThreadRecv()
        {
            NetworkStream ns = new(this.clientSocket);
            StreamReader sr = new StreamReader(ns);
            while (this.isRecv)
            {
                try
                {
                    string data = sr.ReadLine();
                    split(data);
                    //MessageBox.Show($"수신: {data}");
                }
                catch (Exception e)
                {
                    MessageBox.Show($"Exception: {e.Message}");
                    this.isRecv = false;
                    this.clientSocket = null;
                }
            }
            Invalidate();
            MessageBox.Show("서버 접속 종료~");
        }
        private void split(String strPacket)
        {
            String[] dataArr = strPacket.Split(new char[] { '|' });
            string cmd = dataArr[0];
            string data = dataArr[1];
            Console.WriteLine(cmd);

            switch (cmd)
            {
                case "C":
                    enemy_Card = Int32.Parse(data);
                    break;
                case "B":
                    this.tb_stakes.Text = data;
                    break;
                case "G":
                    sendValue(my_Card += $"{rand.Next(14)}");
                    break;
                case "T":
                    turn(Int32.Parse(data));
                    break;
                case "A":
                    betting = Int32.Parse(data);
                    Console.WriteLine("data" + data);
                    break;
                case "W":
                    win = true;
                    winner = Int32.Parse(data);
                    break;
                case "WW":
                    my_Money += Int32.Parse(data);
                    break;
                case "RR":
                    betting = Int32.Parse(data);
                    if (my_Money - betting < 0)
                    {
                        sendValue("U|");
                        MessageBox.Show("돈이 부족합니다. 올-인을 하거나 폴드를 해주세요.");
                    }
                    else
                    {
                        my_Money -= betting;
                    }
                    break;
                case "AL":
                    call = true;
                    break;
                case "CL":
                    clear();
                    break;
            }
            Invalidate();
        }
        private void sendValue(string value)
        {
            if(this.clientSocket != null && this.clientSocket.Connected)
            {
                NetworkStream ns = new(this.clientSocket);
                StreamWriter sw = new(ns);
                sw.WriteLine(value);
                sw.Flush();
            }
            else
            {
                MessageBox.Show("11");
            }
        }
        private void turn(int round = 0)
        {
            isTurn = !isTurn;
            Console.WriteLine(isTurn);
            i = round;
            btn_All_In.Enabled = !isTurn;
            btn_Betting.Enabled = false;
            btn_Call.Enabled = !isTurn;
            btn_Fold.Enabled = !isTurn;
            btn_Raise.Enabled = !isTurn;
            Invalidate();
        }
        private void nud_stakes_ValueChanged(object sender, EventArgs e)
        { 
            this.nud_stakes.Increment = 1000;
        }

        private void btn_Betting_Click(object sender, EventArgs e)
        {
            if (my_Money - (int)nud_stakes.Value < 0)
            {
                MessageBox.Show("돈이 부족합니다. 올-인을 하거나 폴드를 해주세요.");
            }
            else
            {
                value = "B|";
                value += nud_stakes.Value;
                my_Money -= (int)nud_stakes.Value;
                sendValue(value);
            }
        }

        private void btn_Call_Click(object sender, EventArgs e)
        {
            if (call)
            {
                value = "A|";
                value += my_Money;
                my_Money -= my_Money;
                sendValue(value);
            }
            else if (my_Money - betting < 0)
            {
                MessageBox.Show("돈이 부족합니다. 올-인을 하거나 폴드를 해주세요.");
            }
            else
            {
                value = "A|";
                value += betting;
                my_Money -= betting;
                sendValue(value);
            }

        }

        private void btn_Fold_Click(object sender, EventArgs e)
        {
            value = "F|";
            sendValue(value);
        }

        private void clear()
        {
            my_Money = 20000;
            my_Card = "C|";
            value = "";
            enemy_Card = -1;
            isTurn = false;
            i = 0;
            betting = 0;
            win = false;
            winner = -1;
            gameover = false;
            call = false;
        }

        private void btn_Raise_Click(object sender, EventArgs e)
        {
            value = "R|";
            value += nud_stakes.Value;
            sendValue(value);
        }

        private void btn_All_In_Click(object sender, EventArgs e)
        {
            value = "AL|";
            value += my_Money;
            my_Money -= my_Money;
            sendValue(value);
        }
    }
}
