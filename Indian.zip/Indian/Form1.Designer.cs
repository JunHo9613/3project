﻿
namespace Indian
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Call = new System.Windows.Forms.Button();
            this.btn_Raise = new System.Windows.Forms.Button();
            this.btn_Fold = new System.Windows.Forms.Button();
            this.btn_Betting = new System.Windows.Forms.Button();
            this.nud_stakes = new System.Windows.Forms.NumericUpDown();
            this.tb_Money = new System.Windows.Forms.TextBox();
            this.lb_MyMoney = new System.Windows.Forms.Label();
            this.tb_stakes = new System.Windows.Forms.TextBox();
            this.lb_stakes = new System.Windows.Forms.Label();
            this.lb_EnemyCard = new System.Windows.Forms.Label();
            this.btn_All_In = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nud_stakes)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Call
            // 
            this.btn_Call.Font = new System.Drawing.Font("맑은 고딕", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Call.Location = new System.Drawing.Point(26, 460);
            this.btn_Call.Name = "btn_Call";
            this.btn_Call.Size = new System.Drawing.Size(259, 139);
            this.btn_Call.TabIndex = 0;
            this.btn_Call.Text = "콜";
            this.btn_Call.UseVisualStyleBackColor = true;
            this.btn_Call.Click += new System.EventHandler(this.btn_Call_Click);
            // 
            // btn_Raise
            // 
            this.btn_Raise.Font = new System.Drawing.Font("맑은 고딕", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Raise.Location = new System.Drawing.Point(354, 460);
            this.btn_Raise.Name = "btn_Raise";
            this.btn_Raise.Size = new System.Drawing.Size(259, 139);
            this.btn_Raise.TabIndex = 0;
            this.btn_Raise.Text = "레이즈";
            this.btn_Raise.UseVisualStyleBackColor = true;
            this.btn_Raise.Click += new System.EventHandler(this.btn_Raise_Click);
            // 
            // btn_Fold
            // 
            this.btn_Fold.Font = new System.Drawing.Font("맑은 고딕", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Fold.Location = new System.Drawing.Point(674, 460);
            this.btn_Fold.Name = "btn_Fold";
            this.btn_Fold.Size = new System.Drawing.Size(259, 139);
            this.btn_Fold.TabIndex = 0;
            this.btn_Fold.Text = "폴드";
            this.btn_Fold.UseVisualStyleBackColor = true;
            this.btn_Fold.Click += new System.EventHandler(this.btn_Fold_Click);
            // 
            // btn_Betting
            // 
            this.btn_Betting.Location = new System.Drawing.Point(540, 400);
            this.btn_Betting.Name = "btn_Betting";
            this.btn_Betting.Size = new System.Drawing.Size(61, 38);
            this.btn_Betting.TabIndex = 0;
            this.btn_Betting.Text = "베팅";
            this.btn_Betting.UseVisualStyleBackColor = true;
            this.btn_Betting.Click += new System.EventHandler(this.btn_Betting_Click);
            // 
            // nud_stakes
            // 
            this.nud_stakes.Location = new System.Drawing.Point(366, 410);
            this.nud_stakes.Name = "nud_stakes";
            this.nud_stakes.ReadOnly = true;
            this.nud_stakes.Size = new System.Drawing.Size(167, 23);
            this.nud_stakes.TabIndex = 1;
            this.nud_stakes.ValueChanged += new System.EventHandler(this.nud_stakes_ValueChanged);
            // 
            // tb_Money
            // 
            this.tb_Money.Location = new System.Drawing.Point(60, 12);
            this.tb_Money.Name = "tb_Money";
            this.tb_Money.ReadOnly = true;
            this.tb_Money.Size = new System.Drawing.Size(195, 23);
            this.tb_Money.TabIndex = 2;
            // 
            // lb_MyMoney
            // 
            this.lb_MyMoney.AutoSize = true;
            this.lb_MyMoney.Location = new System.Drawing.Point(12, 15);
            this.lb_MyMoney.Name = "lb_MyMoney";
            this.lb_MyMoney.Size = new System.Drawing.Size(42, 15);
            this.lb_MyMoney.TabIndex = 3;
            this.lb_MyMoney.Text = "내 돈 :";
            // 
            // tb_stakes
            // 
            this.tb_stakes.Font = new System.Drawing.Font("맑은 고딕", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_stakes.Location = new System.Drawing.Point(693, 209);
            this.tb_stakes.Name = "tb_stakes";
            this.tb_stakes.ReadOnly = true;
            this.tb_stakes.Size = new System.Drawing.Size(223, 54);
            this.tb_stakes.TabIndex = 5;
            // 
            // lb_stakes
            // 
            this.lb_stakes.AutoSize = true;
            this.lb_stakes.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_stakes.Location = new System.Drawing.Point(777, 143);
            this.lb_stakes.Name = "lb_stakes";
            this.lb_stakes.Size = new System.Drawing.Size(57, 30);
            this.lb_stakes.TabIndex = 6;
            this.lb_stakes.Text = "판돈";
            // 
            // lb_EnemyCard
            // 
            this.lb_EnemyCard.AutoSize = true;
            this.lb_EnemyCard.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_EnemyCard.Location = new System.Drawing.Point(426, 15);
            this.lb_EnemyCard.Name = "lb_EnemyCard";
            this.lb_EnemyCard.Size = new System.Drawing.Size(109, 30);
            this.lb_EnemyCard.TabIndex = 7;
            this.lb_EnemyCard.Text = "상대 카드";
            // 
            // btn_All_In
            // 
            this.btn_All_In.Font = new System.Drawing.Font("맑은 고딕", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_All_In.Location = new System.Drawing.Point(32, 262);
            this.btn_All_In.Name = "btn_All_In";
            this.btn_All_In.Size = new System.Drawing.Size(252, 175);
            this.btn_All_In.TabIndex = 8;
            this.btn_All_In.Text = "올인";
            this.btn_All_In.UseVisualStyleBackColor = true;
            this.btn_All_In.Click += new System.EventHandler(this.btn_All_In_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 616);
            this.Controls.Add(this.btn_All_In);
            this.Controls.Add(this.lb_EnemyCard);
            this.Controls.Add(this.lb_stakes);
            this.Controls.Add(this.tb_stakes);
            this.Controls.Add(this.lb_MyMoney);
            this.Controls.Add(this.tb_Money);
            this.Controls.Add(this.nud_stakes);
            this.Controls.Add(this.btn_Fold);
            this.Controls.Add(this.btn_Betting);
            this.Controls.Add(this.btn_Raise);
            this.Controls.Add(this.btn_Call);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nud_stakes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Call;
        private System.Windows.Forms.Button btn_Raise;
        private System.Windows.Forms.Button btn_Fold;
        private System.Windows.Forms.Button btn_Betting;
        private System.Windows.Forms.NumericUpDown nud_stakes;
        private System.Windows.Forms.TextBox tb_Money;
        private System.Windows.Forms.Label lb_MyMoney;
        private System.Windows.Forms.TextBox tb_stakes;
        private System.Windows.Forms.Label lb_stakes;
        private System.Windows.Forms.Label lb_EnemyCard;
        private System.Windows.Forms.Button btn_All_In;
    }
}

