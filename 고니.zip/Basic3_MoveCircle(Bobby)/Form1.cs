﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Basic3_MoveCircle
{
    public partial class Form1 : Form
    {

        private int x = 300, y = 10;
        private int diameter = 100;
        private Timer timer = new Timer();
        private int d = 10;

        public Form1()
        {
            InitializeComponent();

            this.BackColor = Color.Black;
            this.Paint += Form1_Paint;
            
            this.timer.Interval = 50;
            this.timer.Tick += Timer_Tick;
            timer.Start();

        }

        private void Timer_Tick(object sender, EventArgs e)
        {
          
            
            this.y += d;

            Rectangle rect = this.ClientRectangle;

            if (this.y < rect.Top) 
                d *= -1;
            if (this.y + this.diameter > rect.Bottom)
                d *= -1;

            Invalidate();
        }

     

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Gold, 5);
            g.FillEllipse(Brushes.DarkBlue, this.x, this.y, this.diameter, this.diameter);
            g.DrawEllipse(pen, this.x, this.y, this.diameter, this.diameter);
        }
    }
}
