﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_수용2
{
    public partial class Form1 : Form
    {
        private int x = 10, y = 10;
        private int dmeter = 50;
        private Timer timer = new Timer();
        private int d = 10;
        //private int cnt = 70;
        public Form1()
        {
            InitializeComponent();

            this.BackColor = Color.Black;
            this.Paint += Form1_Paint;
            this.timer.Tick += Timer_Tick;
            this.timer.Start();
            this.timer.Interval = 10;
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            this.y += d;
            Rectangle rect = this.ClientRectangle;
            if (this.y < rect.Top || this.y > rect.Bottom)
                d = d * -1;
            //d *= -1;
            //d= 10;
            //d=-10;
            //y += d;
            Invalidate();
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillEllipse(Brushes.Red, x, y, dmeter, dmeter);

        }
    }
}
