﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test04
{
    public partial class Form1 : Form
    {
        private int x = 10, y = 10;
        private int diameter = 50;
        private Timer timer = new Timer();
        int dictionx = 10, dictiony = 10;

        public Form1()
        {
            InitializeComponent();
            this.Paint += Form1_Paint;
            this.timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Gold, 3);
            g.FillEllipse(Brushes.DarkBlue, this.x, this.y, this.diameter, this.diameter);
            g.DrawEllipse(pen, this.x, this.y, this.diameter, this.diameter);
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            this.y += dictiony;
            this.x += dictionx;

            Rectangle rect = this.ClientRectangle;
            if (this.x < rect.Left ||
                this.x + this.diameter > rect.Right)
                dictionx *= -1;
            if (this.y < rect.Top || this.y + this.diameter > rect.Bottom)
                dictiony *= -1;

            Invalidate();
        }
    }
}
