﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_01
{
    public partial class Form1 : Form
    {
        private int x = 10, y = 10;
        private int diameter = 50;
        private Timer timer = new Timer();
        int dictionx = 10,dictiony = 10;
        int num = 0;

        public Form1()
        {
            InitializeComponent();

            this.Paint += Form1_Paint;
            this.KeyDown += Form1_KeyDown;
            this.timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (num == 2)
                this.y += dictiony;
            else if (num == 1)
                this.x += dictionx;

            Rectangle rect = this.ClientRectangle;
            if (this.x < rect.Left ||
                this.x + this.diameter > rect.Right)
                dictionx = 0;
            if (this.y < rect.Top || this.y + this.diameter > rect.Bottom)
                dictiony = 0;

            Invalidate();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            Keys key = e.KeyCode;
            switch (key)
            {
                // case Keys.Enter:
                // timer.Start();
                //   break;
                case Keys.Left:
                    num = 1;
                    this.dictionx = -10;
                    break;
                case Keys.Right:
                    num = 1;
                    this.dictionx = 10;
                    break;
                case Keys.Up:
                    num = 2;
                    this.dictiony = -10;
                    break;
                case Keys.Down:
                    num = 2;
                    this.dictiony = 10;
                    break;
                case Keys.Enter:
                    num = 0;
                    this.dictiony = 0;
                    this.dictionx = 0;
                    break;
            }
            timer.Start();
            Invalidate();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Gold, 3);
            g.FillEllipse(Brushes.DarkBlue, this.x, this.y, this.diameter, this.diameter);
            g.DrawEllipse(pen, this.x, this.y, this.diameter, this.diameter);
        }
    }
}
