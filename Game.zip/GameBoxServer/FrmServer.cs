﻿using Server;
using Server.DataBase;
using Server.GameHistory;
using Server.History;
using Server.Member;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace GameBoxServer
{
    public partial class FrmServer : Form
    {
        const int port = 9000;

        Socket acceptSocket; // VIPS의 입구에 있는 안내 직원
        IPEndPoint ipep;     // 서버의 주소를 담는 객체

        Thread tAccept;     // 클라이언트 접속허용 스레드 객체
        bool isAccept;      // 스레드가 접속허용 가능여부

        object keyObj = new object();

        // 접속 연결된 클라이언트들을 저장하는 리스트 저장소
        List<Socket> clientList = new List<Socket>();
        static Dictionary<string, Socket> idMap = new Dictionary<string, Socket>();
        static Dictionary<Socket, string> clientMap = new Dictionary<Socket, string>();

        delegate void AddMsgLog(string log);
        AddMsgLog addMsgLog = null;

        MemberDAO memberDAO = new MemberDAO();
        MemberDTO member = new MemberDTO();
        List<MemberDTO> memberList = new List<MemberDTO>();

        GameHistoryDTO history = new GameHistoryDTO();
        GameHistoryDAO historyDAO = new GameHistoryDAO();
        List<GameHistoryDTO> historyList = new List<GameHistoryDTO>();

        public FrmServer()
        {
            InitializeComponent();
        }

        private void Sever_Load(object sender, EventArgs e)
        {
            // addLogListBox 메서드를 델리게이트 변수에 담는다

            this.addMsgLog = this.addLogListBox;
        }

        // 서버시작
        private void RbtnStart_CheckedChanged(object sender, EventArgs e)
        {
            this.acceptSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            this.ipep = new IPEndPoint(IPAddress.Any, port);
            this.acceptSocket.Bind(this.ipep);  // 소켓에 주소 부여
            this.acceptSocket.Listen(100);      // 소켓 대기 큐
            addLogListBox("서버 시작");

            // 클라이언트의 Connect를 Accept할 역할을 담당한 스레드를 생성한다
            this.isAccept = true;
            tAccept = new Thread(new ThreadStart(ThreadAccept));
            tAccept.IsBackground = true;
            tAccept.Start();
        }

        //클라이언트의 Connect 시도를 허용하는 스레드
        void ThreadAccept()
        {
            while (this.isAccept)
            {
                try
                {
                    addLogListBox("서버 접속 대기중...");
                    Socket clientSocket = this.acceptSocket.Accept();

                    lock (this.keyObj)
                    {
                        this.clientList.Add(clientSocket);
                    }
                    addLogListBox("클라이언트 접속 성공");

                    // 해당 클라이언트와 송/수신을 담당할 스레드 생성
                    Thread tRecv = new Thread(new ParameterizedThreadStart(ThreadRecv));
                    tRecv.IsBackground = true;
                    tRecv.Start(clientSocket);
                }
                catch (Exception e)
                {
                    addLogListBox("Exception:" + e.Message);
                }
            }
            addLogListBox("ThreadAccept 종료~");
        }

        //수신+송신
        void ThreadRecv(object sock)
        {
            addLogListBox("클라이언트 담당 스레드 시작!");
            Socket clientSocket = sock as Socket;

            NetworkStream ns = new NetworkStream(clientSocket);
            StreamReader sr = new StreamReader(ns);

            while (true)
            {
                try
                {
                    string data = sr.ReadLine();
                    string[] dataArr = data.Split(new char[] { '|' });

                    //wait : 게임대기실
                    //indianReady : 인디언 Ready한 회원ID와 소지금을 서버에 전달
                    //indianChat : 인디언포커 1:1 채팅
                    //indianCardNum : 인디언포커 카드 번호
                    //cookieReady : 레디 박았을 때, cookieScore : 쿠키런 점수
                    string cmd = dataArr[0];

                    //wait : 본인 아이디, 나머지는 수신자 아이디
                    string id = dataArr[1];

                    //채팅 메세지, 카드번호, 점수
                    string msg = dataArr[2];
                    addLogListBox("");
                    addLogListBox("-----------------------------------------");
                    addLogListBox("cmd : " + cmd);
                    addLogListBox("id : " + id);
                    addLogListBox("msg : " + msg);
                    addLogListBox("-----------------------------------------");
                    addLogListBox("");

                    addMap(clientSocket, id);

                    // WaitingRoom : 게임 대기실(전체 채팅:본인 제외 전체 보내기)
                    if (cmd.Equals("wait"))
                    {
                        sendAllData(data, clientSocket); 
                    }
                    // 특정 클라이언트에게 전송
                    else
                    {
                        switch (cmd)
                        {
                            case "Indian": break;
                            case "cookie":
                                //ready 버튼 눌렀을 때
                                if (msg.Equals("ready"))
                                {
                                    memberDAO.SearchId(id);
                                    member = memberDAO.member;
                                    FindReady();
                                }
                                // 매칭 기다릴 때 
                                else if (msg.Equals("waiting"))
                                {

                                }
                                //게임 결과 cookie|본인아이디|history_Idx
                                else if (msg.Equals("result"))
                                {
                                    GameResultCheck(int.Parse(msg));
                                }
                                break;
                        }
                    }

                }
                catch (Exception e)
                {
                    addLogListBox("Exception:" + e.Message);
                    closeClient(clientSocket);
                    break;
                }
            }
            addLogListBox("ThreadRecv 종료~");
        }

        // Map에 ID추가
        private void addMap(Socket clientSocket, string id)
        {
            Monitor.Enter(keyObj);

            int cnt = 0;

            //현재 메세지를 보낸 클라이언트가 clientMap에 등록되지 않았는지 확인
            //cnt는 0에서 시작하여 현재 클라이언트와 같지 않으면 1씩 증가한다.
            foreach (var map in clientMap)
            {
                if (map.Key != clientSocket)
                {
                    cnt++;
                }
            }

            //cnt가 clientMap.Count와 같은 경우. 즉, clientMap에 등록이 되지 않은경우만 추가한다.
            //해당 조건 없으면 same Key 오류 뜸.
            if (cnt == clientMap.Count)
            {
                clientList.Remove(clientSocket);    
                idMap.Add(id, clientSocket);        //idMap에 Key, Value추가
                clientMap.Add(clientSocket, id);    //clientMap에 Key, Value추가
            }
            Monitor.Exit(keyObj);
        }

        // 접속한 모든 클라이언트한테 데이터를 전송하는 메서드
        void sendAllData(string data, Socket exceptSocket = null)
        {
            lock (this.keyObj)
            {
                string sendId = clientMap[exceptSocket];

                foreach (var map in idMap)
                {
                    string receiveId = map.Key;
                    Socket client = map.Value;
                    if (receiveId != sendId)
                    {
                        NetworkStream ns = new NetworkStream(client);
                        StreamWriter sw = new StreamWriter(ns);
                        sw.WriteLine(data);
                        sw.Flush();
                    }
                }
            }
        }

        // 리스트 박스 로그
        private void addLogListBox(string log)
        {
            if (this.lbLog.InvokeRequired)
            {
                Invoke(this.addMsgLog, new object[] { log });
            }
            else
            {
                this.lbLog.Items.Add(log);  
                this.lbLog.SelectedIndex = this.lbLog.Items.Count - 1;
            }
        }

        // 서버 1개 닫음
        private void closeClient(Socket clientSocket)
        {
            lock (this.keyObj)
            {
                clientList.Remove(clientSocket);
                string id = clientMap[clientSocket];
                clientMap.Remove(clientSocket);
                idMap.Remove(id);
                timer.Stop();
                memberDAO.SearchId(id);
                memberDAO.member.State = "오프라인";
                memberDAO.member.IsConnect = "false";
                memberDAO.UpdateState();
                memberDAO.UpdateConnect();
            }
        }
        
        // 서버관련 전부 닫음
        private void closeAllClient()
        {
            try
            {
                this.isAccept = false;
                this.acceptSocket.Close();

                lock (this.keyObj)
                {
                    foreach (var map in clientMap)
                    {
                        map.Key.Close();
                    }

                    //서버 닫힐 때 모든 회원 상태와 연결여부 초기화
                    memberDAO.SearchAll();
                    foreach(var member in memberDAO.memberList)
                    {
                        member.State = "오프라인";
                        member.IsConnect = "false";
                        memberDAO.member = member;
                        memberDAO.UpdateState();
                        memberDAO.UpdateConnect();
                    }
                }

                timer.Stop();
            }
            catch (Exception ex)
            {
                addLogListBox("Exception: " + ex.Message);
            }
        }
        
        // 서버종료
        private void RbtnStop_CheckedChanged(object sender, EventArgs e)
        {
            closeAllClient();
        }
        
        // 폼 닫힐 때
        private void Sever_FormClosed(object sender, FormClosedEventArgs e)
        {
            closeAllClient();
        }
        
        //타이머
        private void timer_Tick(object sender, EventArgs e)
        {
            RefreshData();
        }

        // 게임 상대방 에게 보내기
        private void gameStartMsg()
        {
            Monitor.Enter(keyObj);

            //보내는 아이디
            string cmd = (history.GameTitle.Equals("인디언 포커")) ? "indianPoker" : "cookieRun";
            string msg = "start";
            Socket Player1_Socket = idMap[history.Player1_Id];
            Socket Player2_Socket = idMap[history.Player2_Id];

            NetworkStream ns1 = new NetworkStream(Player1_Socket);
            StreamWriter sw1 = new StreamWriter(ns1);
            sw1.WriteLine(string.Format("{0}|{1}|{2}", cmd, history.Idx, msg));
            sw1.Flush();

            NetworkStream ns2 = new NetworkStream(Player2_Socket);
            StreamWriter sw2 = new StreamWriter(ns2);
            sw2.WriteLine(string.Format("{0}|{1}|{2}", cmd, history.Idx,msg));
            sw2.Flush();

            Monitor.Exit(keyObj);
        }

        //접속 중인 회원 목록
        private void RefreshData()
        {
            LvConnect.Items.Clear();
            try
            {
                using (SqlConnection conn = new SqlConnection(Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"SELECT [Idx]
                                        ,[Id]
                                        ,[Name]
                                        ,[State]
                                  FROM   [dbo].[MemberTbl]
                                  WHERE  [IsConnect] = 'true'";

                    cmd.CommandText = query;
                    SqlDataReader sr = cmd.ExecuteReader();
                    string[] datas = new string[sr.FieldCount];

                    while (sr.Read())
                    {
                        for (int i = 0; i < sr.FieldCount; i++)
                        {
                            datas[i] = sr.GetValue(i).ToString();
                        }
                        LvConnect.Items.Add(new ListViewItem(datas));
                    }

                    sr.Close();
                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                addLogListBox($"예외발생 : {ex.Message}");
            }
        }

        //회원 상태가 게임 Ready로 바뀐 회원 찾기
        private void FindReady()
        {
            string title = "";
            if (member.State.Equals("인디언 포커 Ready")) title = "인디언 포커";
            else if (member.State.Equals("쿠키런 Ready")) title = "쿠키런";

            historyDAO.SearchAll();
            historyList = historyDAO.historyList;

            int hisCnt = 0;

            addLogListBox(title + "게임 매칭");
            foreach (var his in historyList)
            {
                // 플레이어1만 등록된 곳에 플레이어 2로 등록하고 게임 시작
                if (his.GameTitle.Equals(title) &&
                    his.Player2_Id.Equals("-") &&
                    his.Player2_StartMoney == -1 &&
                    his.WhosWinner.Equals("???"))
                {
                    addLogListBox("플레이어2 : " + history.Player2_Id);
                    addLogListBox("history Idx : " + his.Idx);
                    history.Player1_Score = 0;
                    history.Player2_Id = member.Id;
                    history.Player2_Score = 0;
                    history.Player2_LastMoney = 0;
                    historyDAO.history = history;
                    historyDAO.isNew = false;
                    historyDAO.SaveData();

                    // 회원 상태 게임중으로 변경
                    memberDAO.SearchId(history.Player1_Id);
                    memberDAO.member.State = title + " 게임중";
                    memberDAO.UpdateState();
                    memberDAO.SearchId(history.Player2_Id);
                    memberDAO.member.State = title + " 게임중";
                    memberDAO.UpdateState();
                    gameStartMsg();
                    break;
                }
                hisCnt++;
            }

            // 빈 자리가 없으면 GameHistoryTbl에 플레이어 1로 새로 추가
            if (hisCnt == historyList.Count)
            {
                addLogListBox("플레이어1 : " + history.Player1_Id);
                history.GameTitle = title;
                history.Player1_Id = member.Id;
                history.Player1_StartMoney = member.Money;
                historyDAO.history = history;
                historyDAO.isNew = true;
                historyDAO.SaveData();

                member.State = title + " 매칭중";
                memberDAO.member = member;
                memberDAO.UpdateState();
                addLogListBox(member.Id + " : "+ member.State);
            }
        }
    
        // 게임 끝났는지 확인
        private void GameResultCheck(int historyIdx)
        {
            historyDAO.SearchHistory(historyIdx);

            foreach (var his in historyList)
            {
                // 게임종료 전인 기록들만 확인
                if (his.WhosWinner.Equals("???"))
                {
                    // 플레이어 둘 모두 점수가 나왔다면
                    if (his.Player1_Score != -1 && his.Player2_Score != -1)
                    {
                        // 플레이어 1 승리
                        if (his.Player1_Score > his.Player2_Score)
                        {
                            his.WhosWinner = his.Player1_Id;
                            his.Player1_LastMoney += (his.Player1_Score * 10000);
                            his.Player2_LastMoney -= (his.Player1_Score * 10000);
                        }
                        // 플레이어 2 승리
                        else if (his.Player1_Score < his.Player2_Score)
                        {
                            his.WhosWinner = his.Player2_Id;
                            his.Player1_LastMoney -= (his.Player2_Score * 10000);
                            his.Player2_LastMoney += (his.Player2_Score * 10000);
                        }
                        // 동점
                        else
                        {
                            his.WhosWinner = "WE";
                            his.Player1_LastMoney -= his.Player1_StartMoney;
                            his.Player2_LastMoney += his.Player2_StartMoney;
                        }
                        // 게임 종료 시간
                        his.GameDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        historyDAO.history = history;
                        historyDAO.isNew = false;
                        historyDAO.SaveData();

                        memberDAO.SearchAll();
                        memberList = memberDAO.memberList;

                        // 회원 상태 게임중에서 온라인으로 변경
                        foreach (var mem in memberList)
                        {
                            if (mem.Id.Equals(his.Player1_Id) || mem.Id.Equals(his.Player2_Id))
                            {
                                memberDAO.SearchId(mem.Id);
                                memberDAO.member.State = "온라인";
                                memberDAO.UpdateState();
                                member = memberDAO.member;
                                addLogListBox(member.Id + " : " + member.State);
                            }
                        }
                    }
                }
            }
        }
    }
}
