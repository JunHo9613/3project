﻿
namespace GameBoxServer
{
    partial class FrmServer
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbLog = new System.Windows.Forms.ListBox();
            this.RbtnStart = new System.Windows.Forms.RadioButton();
            this.RbtnStop = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.LvConnect = new System.Windows.Forms.ListView();
            this.columnHeader_Idx = new System.Windows.Forms.ColumnHeader();
            this.columnHeader_ID = new System.Windows.Forms.ColumnHeader();
            this.columnHeader_Name = new System.Windows.Forms.ColumnHeader();
            this.columnHeader_State = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // lbLog
            // 
            this.lbLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbLog.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbLog.FormattingEnabled = true;
            this.lbLog.HorizontalScrollbar = true;
            this.lbLog.ItemHeight = 32;
            this.lbLog.Location = new System.Drawing.Point(660, 128);
            this.lbLog.Name = "lbLog";
            this.lbLog.Size = new System.Drawing.Size(475, 676);
            this.lbLog.TabIndex = 4;
            // 
            // RbtnStart
            // 
            this.RbtnStart.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.RbtnStart.AutoSize = true;
            this.RbtnStart.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.RbtnStart.Location = new System.Drawing.Point(898, 75);
            this.RbtnStart.Name = "RbtnStart";
            this.RbtnStart.Size = new System.Drawing.Size(106, 42);
            this.RbtnStart.TabIndex = 1;
            this.RbtnStart.Text = "Start";
            this.RbtnStart.UseVisualStyleBackColor = true;
            this.RbtnStart.CheckedChanged += new System.EventHandler(this.RbtnStart_CheckedChanged);
            // 
            // RbtnStop
            // 
            this.RbtnStop.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.RbtnStop.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.RbtnStop.Location = new System.Drawing.Point(1030, 75);
            this.RbtnStop.Name = "RbtnStop";
            this.RbtnStop.Size = new System.Drawing.Size(104, 42);
            this.RbtnStop.TabIndex = 2;
            this.RbtnStop.Text = "Stop";
            this.RbtnStop.UseVisualStyleBackColor = true;
            this.RbtnStop.CheckedChanged += new System.EventHandler(this.RbtnStop_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 74);
            this.label1.TabIndex = 4;
            this.label1.Text = "SERVER";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // LvConnect
            // 
            this.LvConnect.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_Idx,
            this.columnHeader_ID,
            this.columnHeader_Name,
            this.columnHeader_State});
            this.LvConnect.HideSelection = false;
            this.LvConnect.Location = new System.Drawing.Point(12, 128);
            this.LvConnect.Name = "LvConnect";
            this.LvConnect.Size = new System.Drawing.Size(640, 704);
            this.LvConnect.TabIndex = 5;
            this.LvConnect.UseCompatibleStateImageBehavior = false;
            this.LvConnect.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader_Idx
            // 
            this.columnHeader_Idx.Text = "No.";
            this.columnHeader_Idx.Width = 100;
            // 
            // columnHeader_ID
            // 
            this.columnHeader_ID.Text = "ID";
            this.columnHeader_ID.Width = 150;
            // 
            // columnHeader_Name
            // 
            this.columnHeader_Name.Text = "Name";
            this.columnHeader_Name.Width = 150;
            // 
            // columnHeader_State
            // 
            this.columnHeader_State.Text = "State";
            this.columnHeader_State.Width = 230;
            // 
            // FrmServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1147, 844);
            this.Controls.Add(this.LvConnect);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RbtnStop);
            this.Controls.Add(this.RbtnStart);
            this.Controls.Add(this.lbLog);
            this.Name = "FrmServer";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Sever_FormClosed);
            this.Load += new System.EventHandler(this.Sever_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbLog;
        private System.Windows.Forms.RadioButton RbtnStart;
        private System.Windows.Forms.RadioButton RbtnStop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ListView LvConnect;
        private System.Windows.Forms.ColumnHeader columnHeader_Idx;
        private System.Windows.Forms.ColumnHeader columnHeader_ID;
        private System.Windows.Forms.ColumnHeader columnHeader_Name;
        private System.Windows.Forms.ColumnHeader columnHeader_State;
    }
}

