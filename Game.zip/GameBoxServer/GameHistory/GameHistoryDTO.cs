﻿namespace Server.History
{
    class GameHistoryDTO
    {
        public int Idx { get; set; }
        public string GameTitle { get; set; }
        public string Player1_Id { get; set; }
        public int Player1_StartMoney { get; set; }
        public int Player1_Score { get; set; }
        public int Player1_LastMoney { get; set; }
        public string Player2_Id { get; set; }
        public int Player2_StartMoney { get; set; }
        public int Player2_Score { get; set; }
        public int Player2_LastMoney { get; set; }
        public string WhosWinner { get; set; }
        public string GameDate { get; set; }
    }
}
