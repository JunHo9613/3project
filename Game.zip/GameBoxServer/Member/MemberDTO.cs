﻿namespace Server.Member
{
    class MemberDTO
    {
        public MemberDTO() { }

        public int Idx { get; set; }
        public string Id { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public int Money { get; set; }
        public string State { get; set; }
        public string IsConnect { get; set; }
        public string RegDate { get; set; }
    }
}