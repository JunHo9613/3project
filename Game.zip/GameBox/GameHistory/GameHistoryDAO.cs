﻿using GameBox.DataBase;
using GameBox.History;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GameBox.GameHistory
{
    class GameHistoryDAO
    {
        public GameHistoryDTO history { get; set; }
        public List<GameHistoryDTO> historyList { get; set; }
        public bool isNew { get; set; }

        public GameHistoryDAO()
        {
            history = new GameHistoryDTO();
            historyList = new List<GameHistoryDTO>();
        }

        // 게임 전적 등록, 수정
        public void SaveData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "";

                    if (isNew == true) // ISNERT
                    {
                        query = @"INSERT INTO [dbo].[GameHistoryTbl]
                                           ([GameTitle]
                                           ,[Player1_Id]
                                           ,[Player1_StartMoney])
                                     VALUES
                                           (@GameTitle
                                           ,@Player1_Id
                                           ,@Player1_StartMoney) ";
                    }
                    else // UPDATE
                    {
                        query = @"UPDATE [dbo].[[GameHistoryTbl]]
                                       SET [GameTitle] = GameTitle
                                          ,[Player1_Id] = @Player1_Id
                                          ,[Player1_StartMoney] = @Player1_StartMoney
                                          ,[Player1_Score] = @Player1_Score
                                          ,[Player1_LastMoney] = @Player1_LastMoney
                                          ,[Player2_Id] = @Player2_Id
                                          ,[Player2_StartMoney] = @Player2_StartMoney
                                          ,[Player2_Score] = @Player2_Score
                                          ,[Player2_LastMoney] = @Player2_LastMoney
                                          ,[WhosWinner] = @WhosWinner
                                          ,[GameDate] = @GameDate
                                     WHERE Idx = @Idx ";
                    }
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@GameTitle", history.GameTitle);
                    cmd.Parameters.AddWithValue("@Player1_Id", history.Player1_Id);
                    cmd.Parameters.AddWithValue("@Player1_StartMoney", history.Player1_StartMoney);
                    cmd.Parameters.AddWithValue("@Player1_Score", history.Player1_Score);
                    cmd.Parameters.AddWithValue("@Player1_LastMoney", history.Player1_LastMoney);
                    cmd.Parameters.AddWithValue("@Player2_Id", history.Player2_Id);
                    cmd.Parameters.AddWithValue("@Player2_StartMoney", history.Player2_StartMoney);
                    cmd.Parameters.AddWithValue("@Player2_LastMoney", history.Player2_LastMoney);
                    cmd.Parameters.AddWithValue("@WhosWinner", history.WhosWinner);
                    cmd.Parameters.AddWithValue("@GameDate", history.GameDate);

                    if (isNew == false) // Update 일때만 처리
                    {
                        cmd.Parameters.AddWithValue("@Idx", history.Idx);
                    }

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Server GameHistoryDAO SaveData 예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 게임 종료 날짜 업데이트
        public void UpdateGameDate()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[[GameHistoryTbl]]
                                       SET [GameDate] = @GameDate
                                     WHERE Idx = @Idx ";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@GameDate", history.GameDate);
                    cmd.Parameters.AddWithValue("@Idx", history.Idx);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Server GameHistoryDAO SaveData 예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // History찾기
        public void SearchHistory(int idx)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"SELECT [Idx]
                                        ,[GameTitle]
                                        ,[Player1_Id]
                                        ,[Player1_StartMoney]
                                        ,[Player1_Score]
                                        ,[Player1_LastMoney]
                                        ,[Player2_Id]
                                        ,[Player2_StartMoney]
                                        ,[Player2_Score]
                                        ,[Player2_LastMoney]
                                        ,[WhosWinner]
                                        ,[GameDate]
                                    FROM [dbo].[GameHistoryTbl]
                                  WHERE  [Idx] = @Idx";

                    cmd.CommandText = query;
                    cmd.Parameters.AddWithValue("@Idx", idx);

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];
                    if (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            Console.WriteLine(datas[i] + "/");
                            datas[i] = reader.GetValue(i).ToString();
                        }

                        history.Idx = int.Parse(datas[0]);
                        history.GameTitle = datas[1];
                        history.Player1_Id = datas[2];
                        history.Player1_StartMoney = int.Parse(datas[3]);
                        history.Player1_Score = int.Parse(datas[4]);
                        history.Player1_LastMoney = int.Parse(datas[5]);
                        history.Player2_Id = datas[6];
                        history.Player2_StartMoney = int.Parse(datas[7]);
                        history.Player2_Score = int.Parse(datas[8]);
                        history.Player2_LastMoney = int.Parse(datas[9]);
                        history.WhosWinner = datas[10];
                        history.GameDate = datas[11];
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 모든 전적
        public void SearchAll()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"SELECT *
                                  FROM [dbo].[GameHistoryTbl] ";
                    cmd.CommandText = query;

                    SqlDataReader sr = cmd.ExecuteReader();
                    string[] datas = new string[sr.FieldCount];

                    historyList.Clear();
                    while (sr.Read())
                    {
                        for (int i = 0; i < sr.FieldCount; i++)
                        {
                            datas[i] = sr.GetValue(i).ToString();
                        }

                        GameHistoryDTO history = new GameHistoryDTO();
                        history.Idx = int.Parse(datas[0]);
                        history.GameTitle = datas[1];
                        history.Player1_Id = datas[2];
                        history.Player1_StartMoney = int.Parse(datas[3]);
                        history.Player1_Score = int.Parse(datas[4]);
                        history.Player1_LastMoney = int.Parse(datas[5]);
                        history.Player2_Id = datas[6];
                        history.Player2_StartMoney = int.Parse(datas[7]);
                        history.Player2_Score = int.Parse(datas[8]);
                        history.Player2_LastMoney = int.Parse(datas[9]);
                        history.WhosWinner = datas[10];
                        history.GameDate = datas[11];
                        historyList.Add(history);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"MemberDAO SearchAll() 예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
