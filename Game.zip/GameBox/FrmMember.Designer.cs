﻿
namespace GameBox
{
    partial class FrmMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.MyInfo_Name = new System.Windows.Forms.TextBox();
            this.MyInfo_Phone = new System.Windows.Forms.TextBox();
            this.MyInfo_GM = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.MyInfo_RD = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.MyInfo_ID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.MyInfo_PW = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(265, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "회원 정보";
            // 
            // MyInfo_Name
            // 
            this.MyInfo_Name.BackColor = System.Drawing.Color.White;
            this.MyInfo_Name.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MyInfo_Name.Location = new System.Drawing.Point(286, 334);
            this.MyInfo_Name.Name = "MyInfo_Name";
            this.MyInfo_Name.ReadOnly = true;
            this.MyInfo_Name.Size = new System.Drawing.Size(315, 50);
            this.MyInfo_Name.TabIndex = 1;
            // 
            // MyInfo_Phone
            // 
            this.MyInfo_Phone.BackColor = System.Drawing.Color.White;
            this.MyInfo_Phone.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MyInfo_Phone.Location = new System.Drawing.Point(287, 415);
            this.MyInfo_Phone.Name = "MyInfo_Phone";
            this.MyInfo_Phone.ReadOnly = true;
            this.MyInfo_Phone.Size = new System.Drawing.Size(314, 50);
            this.MyInfo_Phone.TabIndex = 2;
            // 
            // MyInfo_GM
            // 
            this.MyInfo_GM.BackColor = System.Drawing.Color.White;
            this.MyInfo_GM.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MyInfo_GM.Location = new System.Drawing.Point(285, 496);
            this.MyInfo_GM.Name = "MyInfo_GM";
            this.MyInfo_GM.ReadOnly = true;
            this.MyInfo_GM.Size = new System.Drawing.Size(316, 50);
            this.MyInfo_GM.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(117, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 45);
            this.label2.TabIndex = 0;
            this.label2.Text = "비밀번호";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(265, 381);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 45);
            this.label3.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(149, 415);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 45);
            this.label4.TabIndex = 0;
            this.label4.Text = "연락처";
            // 
            // MyInfo_RD
            // 
            this.MyInfo_RD.BackColor = System.Drawing.Color.White;
            this.MyInfo_RD.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MyInfo_RD.Location = new System.Drawing.Point(285, 577);
            this.MyInfo_RD.Name = "MyInfo_RD";
            this.MyInfo_RD.ReadOnly = true;
            this.MyInfo_RD.Size = new System.Drawing.Size(316, 50);
            this.MyInfo_RD.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(149, 496);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 45);
            this.label5.TabIndex = 0;
            this.label5.Text = "소지금";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(117, 577);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 45);
            this.label6.TabIndex = 0;
            this.label6.Text = "가입날짜";
            // 
            // MyInfo_ID
            // 
            this.MyInfo_ID.BackColor = System.Drawing.Color.White;
            this.MyInfo_ID.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MyInfo_ID.Location = new System.Drawing.Point(284, 172);
            this.MyInfo_ID.Name = "MyInfo_ID";
            this.MyInfo_ID.ReadOnly = true;
            this.MyInfo_ID.Size = new System.Drawing.Size(317, 50);
            this.MyInfo_ID.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(149, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 45);
            this.label7.TabIndex = 0;
            this.label7.Text = "아이디";
            // 
            // MyInfo_PW
            // 
            this.MyInfo_PW.BackColor = System.Drawing.Color.White;
            this.MyInfo_PW.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MyInfo_PW.Location = new System.Drawing.Point(286, 253);
            this.MyInfo_PW.Name = "MyInfo_PW";
            this.MyInfo_PW.ReadOnly = true;
            this.MyInfo_PW.Size = new System.Drawing.Size(315, 50);
            this.MyInfo_PW.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(181, 334);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 45);
            this.label8.TabIndex = 0;
            this.label8.Text = "이름";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.MyInfo_PW);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.MyInfo_ID);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.MyInfo_RD);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.MyInfo_GM);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.MyInfo_Phone);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.MyInfo_Name);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(61, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(730, 660);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // FrmMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(35F, 50F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(852, 687);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("휴먼둥근헤드라인", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "FrmMember";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "회원 정보 보기";
            this.Load += new System.EventHandler(this.FrmMember_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox MyInfo_Name;
        private System.Windows.Forms.TextBox MyInfo_Phone;
        private System.Windows.Forms.TextBox MyInfo_GM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox MyInfo_RD;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox MyInfo_ID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox MyInfo_PW;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}