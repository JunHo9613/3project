﻿
namespace GameBox
{
    partial class FrmMemberUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UpInfo_PW = new System.Windows.Forms.TextBox();
            this.UpInfo_ID = new System.Windows.Forms.TextBox();
            this.UpInfo_Phone = new System.Windows.Forms.TextBox();
            this.UpInfo_Name = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_UpInfo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // UpInfo_PW
            // 
            this.UpInfo_PW.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UpInfo_PW.Location = new System.Drawing.Point(336, 270);
            this.UpInfo_PW.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.UpInfo_PW.Name = "UpInfo_PW";
            this.UpInfo_PW.Size = new System.Drawing.Size(343, 50);
            this.UpInfo_PW.TabIndex = 20;
            // 
            // UpInfo_ID
            // 
            this.UpInfo_ID.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UpInfo_ID.Location = new System.Drawing.Point(334, 173);
            this.UpInfo_ID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.UpInfo_ID.Name = "UpInfo_ID";
            this.UpInfo_ID.Size = new System.Drawing.Size(345, 50);
            this.UpInfo_ID.TabIndex = 19;
            // 
            // UpInfo_Phone
            // 
            this.UpInfo_Phone.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UpInfo_Phone.Location = new System.Drawing.Point(336, 464);
            this.UpInfo_Phone.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.UpInfo_Phone.Name = "UpInfo_Phone";
            this.UpInfo_Phone.Size = new System.Drawing.Size(341, 50);
            this.UpInfo_Phone.TabIndex = 16;
            // 
            // UpInfo_Name
            // 
            this.UpInfo_Name.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UpInfo_Name.Location = new System.Drawing.Point(336, 367);
            this.UpInfo_Name.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.UpInfo_Name.Name = "UpInfo_Name";
            this.UpInfo_Name.Size = new System.Drawing.Size(343, 50);
            this.UpInfo_Name.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(163, 466);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 45);
            this.label4.TabIndex = 9;
            this.label4.Text = "전화번호";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(297, 580);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 45);
            this.label3.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(195, 175);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 45);
            this.label7.TabIndex = 11;
            this.label7.Text = "아이디";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(227, 370);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 45);
            this.label8.TabIndex = 12;
            this.label8.Text = "이름";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(163, 272);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 45);
            this.label2.TabIndex = 13;
            this.label2.Text = "비밀번호";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(278, 57);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(319, 60);
            this.label1.TabIndex = 14;
            this.label1.Text = "회원 정보 수정";
            // 
            // btn_UpInfo
            // 
            this.btn_UpInfo.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_UpInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UpInfo.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_UpInfo.ForeColor = System.Drawing.Color.White;
            this.btn_UpInfo.Location = new System.Drawing.Point(335, 568);
            this.btn_UpInfo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_UpInfo.Name = "btn_UpInfo";
            this.btn_UpInfo.Size = new System.Drawing.Size(177, 68);
            this.btn_UpInfo.TabIndex = 21;
            this.btn_UpInfo.Text = "수정";
            this.btn_UpInfo.UseVisualStyleBackColor = false;
            this.btn_UpInfo.Click += new System.EventHandler(this.btn_UpInfo_Click);
            // 
            // FrmMemberUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(852, 687);
            this.Controls.Add(this.btn_UpInfo);
            this.Controls.Add(this.UpInfo_PW);
            this.Controls.Add(this.UpInfo_ID);
            this.Controls.Add(this.UpInfo_Phone);
            this.Controls.Add(this.UpInfo_Name);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmMemberUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "회원 정보 수정";
            this.Load += new System.EventHandler(this.FrmMemberUp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox UpInfo_PW;
        private System.Windows.Forms.TextBox UpInfo_ID;
        private System.Windows.Forms.TextBox UpInfo_Phone;
        private System.Windows.Forms.TextBox UpInfo_Name;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_UpInfo;
    }
}