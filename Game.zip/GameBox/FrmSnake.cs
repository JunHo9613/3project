﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmSnake : Form
    {
        //방향 구조체
        public enum Direction
        {
            LEFT,
            RIGHT,
            UP,
            DOWN
        }
        Direction direction;

        //뱀
        const int InitSnakeCnt = 5;
        const int Rect_WIDTH = 30;      // 뱀 몸통 너비
        const int Rect_HEIGHT = 30;     // 뱀 몸통 높이
        const int startX = 400;         // 왼쪽 시작 위치
        const int startY = 400;         // 위 시작 위치
        List<Rectangle> snakeList = new List<Rectangle>();

        //먹이
        const int InitFoodCnt = 5;
        List<Rectangle> foodList = new List<Rectangle>();

        //벽
        Rectangle wall;

        //스피드
        const int speed = 30;
        //점수
        int score;
        //게임시작 여부
        bool isPlay;               


        Random rand = new Random();

        public FrmSnake()
        {
            InitializeComponent();
        }

        //초기
        private void FrmSnake_Load(object sender, EventArgs e)
        {
            makeSnake();    //뱀 생성
            makeWalls();    //벽 생성
            makeFood();     //먹이 생성
            score = 0;      //점수 0
            isPlay = false; //게임 시작 여부
            Invalidate();
        }

        //뱀 생성
        private void makeSnake()
        {
            //InitSnakeCnt 크기만큼 몸통 생성
            for (int i = 0; i < InitSnakeCnt; i++)
            {
                Rectangle snake = new Rectangle(startX, startY + (i + 1) * Rect_WIDTH, Rect_WIDTH, Rect_HEIGHT);
                snakeList.Add(snake);
            }
        }

        //먹이 생성
        private void makeFood()
        {
            //InitFoodCnt 개 수만큼 먹이 생성
            for (int i = 0; i < InitFoodCnt; i++)
            {
                //52 : 벽 너비 만큼 더 해줌
                int x = rand.Next(wall.Width) + 52;
                int y = rand.Next(wall.Height) + 52;

                //먹이가 벽 넘어가면 다시 좌표 설정
                if (x >= wall.Width - Rect_WIDTH || y >= wall.Height - Rect_HEIGHT)
                {
                    i--;
                    continue;
                }

                //위에서 설정한 랜덤좌표에 먹이 생성
                Rectangle food = new Rectangle(x, y, Rect_WIDTH, Rect_HEIGHT);
                foodList.Add(food);
            }
        }

        //벽 생성(먹이와 뱀은 벽 안에 생성이 되어 밖으로 나갈 수 없음)
        private void makeWalls()
        {
            //52 : 벽 너비, -125 & -150 : 정사각형 모양 나오려면 해당값 넣어야함 
            wall = new Rectangle(52, 52, Width - 125, Height - 150);
        }

        //뱀 움직이기
        private void moveSnake()
        {
            //머리를 제외한 몸통은 꼬리부터 앞쪽으로 이동
            for(int i = snakeList.Count - 1; i > 0; i--)
            {
                snakeList[i] = new Rectangle(snakeList[i - 1].X, snakeList[i - 1].Y, Rect_WIDTH, Rect_HEIGHT);
            }
            switch (direction)
            {
                case Direction.LEFT:    //왼쪽
                    snakeList[0] = new Rectangle(snakeList[0].X - speed, snakeList[0].Y, Rect_WIDTH, Rect_HEIGHT);
                    break;
                case Direction.RIGHT:   //오른쪽
                    snakeList[0] = new Rectangle(snakeList[0].X + speed, snakeList[0].Y, Rect_WIDTH, Rect_HEIGHT);
                    break;
                case Direction.UP:      //위
                    snakeList[0] = new Rectangle(snakeList[0].X, snakeList[0].Y - speed, Rect_WIDTH, Rect_HEIGHT);
                    break;
                case Direction.DOWN:    //아래
                    snakeList[0] = new Rectangle(snakeList[0].X, snakeList[0].Y + speed, Rect_WIDTH, Rect_HEIGHT);
                    break;
            }
        }

        //먹이 충돌 검사
        private void checkBumpFood()
        {
            foreach(var food in foodList)
            {
                if(snakeList[0].IntersectsWith(food))
                {
                    score += 30;
                    snakeList.Add(food);
                    foodList.Remove(food);
                    break;
                }
            }

            //먹이 없어지면 추가 적으로 뿌려줌
            if(foodList.Count < 4)
            {
                while (true)
                {
                    int x = rand.Next(wall.Width) + 52;
                    int y = rand.Next(wall.Height) + 52;
                    if (x >= wall.Width - Rect_WIDTH || y >= wall.Height - Rect_HEIGHT)
                    {
                        continue;
                    }
                    Rectangle food = new Rectangle(x, y, Rect_WIDTH, Rect_HEIGHT);
                    foodList.Add(food);
                    break;
                }
            }
        }

        //벽 충돌 검사(뱀은 벽안에 존재해야함)
        private void checkBumpWall()
        {
            /*if (snakeList[0].Left <= wall.Left ||
                snakeList[0].Right >= wall.Right ||
                snakeList[0].Top <= wall.Top ||
                snakeList[0].Bottom >= wall.Bottom)*/

            //IntersectsWith : Rectangle 충돌여부 확인
            //뱀 머리가 벽과 충돌 했다면
            if (!snakeList[0].IntersectsWith(wall))
            {
                if (snakeList[0].Left <= wall.Left)
                {
                    snakeList[0] = new Rectangle(wall.Left, snakeList[0].Top, Rect_WIDTH, Rect_HEIGHT);
                }
                if (snakeList[0].Right >= wall.Right)
                {
                    snakeList[0] = new Rectangle(wall.Right - Rect_WIDTH, snakeList[0].Top, Rect_WIDTH, Rect_HEIGHT);
                }
                if (snakeList[0].Top <= wall.Top)
                {
                    snakeList[0] = new Rectangle(snakeList[0].X, wall.Top, Rect_WIDTH, Rect_HEIGHT);
                }
                if (snakeList[0].Bottom >= wall.Bottom)
                {
                    snakeList[0] = new Rectangle(snakeList[0].X, wall.Bottom - Rect_HEIGHT, Rect_WIDTH, Rect_HEIGHT);
                }

                //머리를 지워라
                snakeList.RemoveAt(0);
                score -= 10;
            }
        }

        //게임 시작 했는지
        private void checkPlay()
        {
            if (!isPlay)
            {
                isPlay = true;
                timer.Enabled = true;
            }
        }

        //게임오버체크
        private void checkGameOver()
        {
            if (snakeList.Count < 1)
            {
                timer.Stop();
                MessageBox.Show("Game Over\nScore : "+score);
                this.Close();
            }
            else if (score >= 300)
            {
                timer.Stop();
                MessageBox.Show("YOU WIN\nScore : " + score);
                this.Close();
            }
        }

        //키보드 입력
        private void FrmSnake_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    checkPlay();
                    direction = Direction.LEFT;
                    break;
                case Keys.Right:
                    checkPlay();
                    direction = Direction.RIGHT;
                    break;
                case Keys.Up:
                    checkPlay();
                    direction = Direction.UP;
                    break;
                case Keys.Down:
                    checkPlay();
                    direction = Direction.DOWN;
                    break;
            }
            Invalidate();
        }

        //타이머
        private void timer_Tick(object sender, EventArgs e)
        {
            moveSnake();        //뱀 움직임
            checkBumpFood();    //먹이 충돌 체크
            checkBumpWall();    //벽 충돌 체크
            checkGameOver();    //게임 오버 체크
            Invalidate();
        }

        //화면 출력
        private void FrmSnake_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Brushes.White, 2f);

            //벽 출력
            e.Graphics.DrawRectangle(pen, wall);
            e.Graphics.FillRectangle(Brushes.Black, wall);

            //먹이 출력
            for (int i = 0; i < foodList.Count; i++)
            {
                e.Graphics.FillRectangle(Brushes.Red, foodList[i]);
            }

            pen = new Pen(Brushes.GreenYellow, 2f);
            //뱀 출력
            for (int i = 0; i < snakeList.Count; i++)
            {
                e.Graphics.DrawRectangle(pen, snakeList[i]);
                e.Graphics.FillRectangle(Brushes.DarkGreen, snakeList[i]);
            }

            //창 아이콘 옆에 글자 출력
            Text = "Snake Game | Score : " + score.ToString();
        }
    }
}
