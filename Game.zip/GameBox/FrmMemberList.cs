﻿using GameBox.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmMemberList : Form
    {
        SqlConnection conn = null;
        public FrmMemberList()
        {
            InitializeComponent();
        }

        private void FrmMemberList_Load(object sender, EventArgs e)
        {
            this.conn = new SqlConnection(Common.ConnString);
            this.conn.Open();

            lv_table.Items.Clear();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = this.conn;
                cmd.CommandText = "select * from dbo.MemberTbl";

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string[] datas = new string[reader.FieldCount];

                    for (int i = 0; i < datas.Length; i++)
                        datas[i] = reader.GetValue(i).ToString();

                    lv_table.Items.Add(new ListViewItem(datas));
                }

                reader.Close();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외 : " + ex.Message);
            }
        }

      /*  void runSelectCmd()
        {
            lv_table.Items.Clear();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = this.conn;
                cmd.CommandText = "select * from dbo.MemberTbl";

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string[] datas = new string[reader.FieldCount];

                    for (int i = 0; i < datas.Length; i++)
                        datas[i] = reader.GetValue(i).ToString();

                    lv_table.Items.Add(new ListViewItem(datas));
                }

                reader.Close();
                cmd.Dispose();
            }
            catch(Exception ex)
            {
                MessageBox.Show("예외 : " + ex.Message);
            }
        }
        void DBConnect()
        {
            this.conn = new SqlConnection(this.connInfo);
            try
            {
                this.conn.Open();
                
            }catch(Exception ex)
            {
                if (this.conn != null &&
                    this.conn.State == ConnectionState.Open ||
                    this.conn.State == ConnectionState.Connecting)
                    this.conn.Close();
                this.conn = null;
                return;

            }

          
        }
*/

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
