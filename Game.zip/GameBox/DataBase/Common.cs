﻿using System.Net;

namespace GameBox.DataBase
{
    public class Common
    {
        public static string ConnString = "Data Source=DESKTOP-DB9NMIA;Initial Catalog=GameBoxDB;Persist Security Info=True;User ID=sa;Password=12341234";

        public static string LoginUserId = string.Empty;

        /// <summary>
        /// 아이피주소 받아오는 메서드
        /// </summary>
        /// <returns></returns>
        internal static string GetLocalIp()
        {
            string localIP = "";
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    localIP = ip.ToString();
                    break;
                }
            }

            return localIP;
        }

        internal static string ReplaceCmdText(string strSource)
        {
            var result = strSource.Replace("'", "＇");
            result = result.Replace("--", "");
            result = result.Replace(";", "");

            return result;
        }
    }
}
