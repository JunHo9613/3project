﻿using GameBox.Member;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmMember : Form
    {
        MemberDAO memdao = new MemberDAO();
        MemberDTO memdto = new MemberDTO();
        string id;

        public FrmMember(string id)
        {
            this.id = id;
            InitializeComponent();
        }
        private void FrmMember_Load(object sender, System.EventArgs e)
        {

            memdao.SearchId(id);
            memdto = memdao.member;

            //memdao.StateMy(id);


            MyInfo_ID.Text = memdto.Id;
            MyInfo_PW.Text = memdto.Password;
            MyInfo_Name.Text = memdto.Name;
            MyInfo_Phone.Text = memdto.Phone;
            MyInfo_GM.Text = memdto.Money.ToString();
            MyInfo_RD.Text = memdto.RegDate;
        }
    }
}
