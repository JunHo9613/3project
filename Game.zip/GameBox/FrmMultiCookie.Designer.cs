﻿
namespace GameBox
{
    partial class FrmMultiCookie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MnuTop = new System.Windows.Forms.MenuStrip();
            this.MnuMyScore = new System.Windows.Forms.ToolStripTextBox();
            this.MnuMyScoreValue = new System.Windows.Forms.ToolStripTextBox();
            this.MnuStartMoney = new System.Windows.Forms.ToolStripTextBox();
            this.MnuStartMoneyValue = new System.Windows.Forms.ToolStripTextBox();
            this.MnuLastMoney = new System.Windows.Forms.ToolStripTextBox();
            this.MnuLastMoneyValue = new System.Windows.Forms.ToolStripTextBox();
            this.MnuBottom = new System.Windows.Forms.MenuStrip();
            this.MnuWinnerId = new System.Windows.Forms.ToolStripTextBox();
            this.MnuWinnerIdValue = new System.Windows.Forms.ToolStripTextBox();
            this.MnuWinnerScore = new System.Windows.Forms.ToolStripTextBox();
            this.MnuWinnerScoreValue = new System.Windows.Forms.ToolStripTextBox();
            this.MnuResult = new System.Windows.Forms.ToolStripTextBox();
            this.MnuResultValue = new System.Windows.Forms.ToolStripTextBox();
            this.MnuTop.SuspendLayout();
            this.MnuBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnuTop
            // 
            this.MnuTop.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuTop.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.MnuTop.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuMyScore,
            this.MnuMyScoreValue,
            this.MnuStartMoney,
            this.MnuStartMoneyValue,
            this.MnuLastMoney,
            this.MnuLastMoneyValue});
            this.MnuTop.Location = new System.Drawing.Point(0, 0);
            this.MnuTop.Name = "MnuTop";
            this.MnuTop.Size = new System.Drawing.Size(1498, 49);
            this.MnuTop.TabIndex = 0;
            this.MnuTop.Text = "menuStrip1";
            // 
            // MnuMyScore
            // 
            this.MnuMyScore.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuMyScore.Name = "MnuMyScore";
            this.MnuMyScore.Size = new System.Drawing.Size(235, 45);
            this.MnuMyScore.Text = "내 점수";
            this.MnuMyScore.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuMyScoreValue
            // 
            this.MnuMyScoreValue.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuMyScoreValue.Name = "MnuMyScoreValue";
            this.MnuMyScoreValue.Size = new System.Drawing.Size(235, 45);
            this.MnuMyScoreValue.Text = "0";
            this.MnuMyScoreValue.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuStartMoney
            // 
            this.MnuStartMoney.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuStartMoney.Name = "MnuStartMoney";
            this.MnuStartMoney.Size = new System.Drawing.Size(235, 45);
            this.MnuStartMoney.Text = "시작 소지금";
            this.MnuStartMoney.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuStartMoneyValue
            // 
            this.MnuStartMoneyValue.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuStartMoneyValue.Name = "MnuStartMoneyValue";
            this.MnuStartMoneyValue.Size = new System.Drawing.Size(235, 45);
            this.MnuStartMoneyValue.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuLastMoney
            // 
            this.MnuLastMoney.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuLastMoney.Name = "MnuLastMoney";
            this.MnuLastMoney.Size = new System.Drawing.Size(235, 45);
            this.MnuLastMoney.Text = "최종 소지금";
            this.MnuLastMoney.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuLastMoneyValue
            // 
            this.MnuLastMoneyValue.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuLastMoneyValue.Name = "MnuLastMoneyValue";
            this.MnuLastMoneyValue.Size = new System.Drawing.Size(235, 45);
            this.MnuLastMoneyValue.Text = "0";
            this.MnuLastMoneyValue.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuBottom
            // 
            this.MnuBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.MnuBottom.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuBottom.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.MnuBottom.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuWinnerId,
            this.MnuWinnerIdValue,
            this.MnuWinnerScore,
            this.MnuWinnerScoreValue,
            this.MnuResult,
            this.MnuResultValue});
            this.MnuBottom.Location = new System.Drawing.Point(0, 945);
            this.MnuBottom.Name = "MnuBottom";
            this.MnuBottom.Size = new System.Drawing.Size(1498, 49);
            this.MnuBottom.TabIndex = 1;
            this.MnuBottom.Text = "menuStrip2";
            // 
            // MnuWinnerId
            // 
            this.MnuWinnerId.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuWinnerId.Name = "MnuWinnerId";
            this.MnuWinnerId.Size = new System.Drawing.Size(235, 45);
            this.MnuWinnerId.Text = "승자 아이디";
            this.MnuWinnerId.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuWinnerIdValue
            // 
            this.MnuWinnerIdValue.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuWinnerIdValue.Name = "MnuWinnerIdValue";
            this.MnuWinnerIdValue.Size = new System.Drawing.Size(235, 45);
            this.MnuWinnerIdValue.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuWinnerScore
            // 
            this.MnuWinnerScore.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuWinnerScore.Name = "MnuWinnerScore";
            this.MnuWinnerScore.Size = new System.Drawing.Size(235, 45);
            this.MnuWinnerScore.Text = "승자 점수";
            this.MnuWinnerScore.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuWinnerScoreValue
            // 
            this.MnuWinnerScoreValue.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuWinnerScoreValue.Name = "MnuWinnerScoreValue";
            this.MnuWinnerScoreValue.Size = new System.Drawing.Size(235, 45);
            this.MnuWinnerScoreValue.Text = "0";
            this.MnuWinnerScoreValue.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuResult
            // 
            this.MnuResult.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuResult.Name = "MnuResult";
            this.MnuResult.Size = new System.Drawing.Size(235, 45);
            this.MnuResult.Text = "게임결과";
            this.MnuResult.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MnuResultValue
            // 
            this.MnuResultValue.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuResultValue.Name = "MnuResultValue";
            this.MnuResultValue.Size = new System.Drawing.Size(235, 45);
            this.MnuResultValue.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FrmMultiCookie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1498, 994);
            this.Controls.Add(this.MnuBottom);
            this.Controls.Add(this.MnuTop);
            this.MainMenuStrip = this.MnuTop;
            this.Name = "FrmMultiCookie";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "멀티게임 - 쿠키런";
            this.Load += new System.EventHandler(this.FrmMultiCookie_Load);
            this.MnuTop.ResumeLayout(false);
            this.MnuTop.PerformLayout();
            this.MnuBottom.ResumeLayout(false);
            this.MnuBottom.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuTop;
        private System.Windows.Forms.ToolStripTextBox MnuMyScore;
        private System.Windows.Forms.ToolStripTextBox MnuMyScoreValue;
        private System.Windows.Forms.ToolStripTextBox MnuStartMoney;
        private System.Windows.Forms.ToolStripTextBox MnuStartMoneyValue;
        private System.Windows.Forms.ToolStripTextBox MnuLastMoney;
        private System.Windows.Forms.ToolStripTextBox MnuLastMoneyValue;
        private System.Windows.Forms.MenuStrip MnuBottom;
        private System.Windows.Forms.ToolStripTextBox MnuWinnerId;
        private System.Windows.Forms.ToolStripTextBox MnuWinnerIdValue;
        private System.Windows.Forms.ToolStripTextBox MnuWinnerScore;
        private System.Windows.Forms.ToolStripTextBox MnuWinnerScoreValue;
        private System.Windows.Forms.ToolStripTextBox MnuResult;
        private System.Windows.Forms.ToolStripTextBox MnuResultValue;
    }
}