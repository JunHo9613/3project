﻿
namespace GameBox
{
    partial class FrmFind
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnIdFind = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtIdName = new System.Windows.Forms.TextBox();
            this.TxtPwId = new System.Windows.Forms.TextBox();
            this.TxtIdPhone = new System.Windows.Forms.TextBox();
            this.BtnPasswordFind = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtIdResult = new System.Windows.Forms.TextBox();
            this.TxtPasswordResult = new System.Windows.Forms.TextBox();
            this.TxtPwPhone = new System.Windows.Forms.TextBox();
            this.TxtPwName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnIdFind
            // 
            this.BtnIdFind.BackColor = System.Drawing.SystemColors.Highlight;
            this.BtnIdFind.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnIdFind.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnIdFind.ForeColor = System.Drawing.Color.White;
            this.BtnIdFind.Location = new System.Drawing.Point(622, 213);
            this.BtnIdFind.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.BtnIdFind.Name = "BtnIdFind";
            this.BtnIdFind.Size = new System.Drawing.Size(165, 143);
            this.BtnIdFind.TabIndex = 0;
            this.BtnIdFind.Text = "검색";
            this.BtnIdFind.UseVisualStyleBackColor = false;
            this.BtnIdFind.Click += new System.EventHandler(this.BtnIdFind_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(265, 66);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(285, 65);
            this.label1.TabIndex = 1;
            this.label1.Text = "아이디 찾기";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(186, 612);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 45);
            this.label2.TabIndex = 2;
            this.label2.Text = "ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(152, 216);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 45);
            this.label4.TabIndex = 4;
            this.label4.Text = "이름";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(84, 302);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(148, 45);
            this.label5.TabIndex = 5;
            this.label5.Text = "전화번호";
            // 
            // TxtIdName
            // 
            this.TxtIdName.BackColor = System.Drawing.SystemColors.Window;
            this.TxtIdName.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtIdName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TxtIdName.Location = new System.Drawing.Point(265, 213);
            this.TxtIdName.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.TxtIdName.MaxLength = 5;
            this.TxtIdName.Name = "TxtIdName";
            this.TxtIdName.Size = new System.Drawing.Size(320, 50);
            this.TxtIdName.TabIndex = 6;
            // 
            // TxtPwId
            // 
            this.TxtPwId.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtPwId.Location = new System.Drawing.Point(265, 612);
            this.TxtPwId.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.TxtPwId.MaxLength = 12;
            this.TxtPwId.Name = "TxtPwId";
            this.TxtPwId.Size = new System.Drawing.Size(320, 50);
            this.TxtPwId.TabIndex = 7;
            // 
            // TxtIdPhone
            // 
            this.TxtIdPhone.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtIdPhone.Location = new System.Drawing.Point(265, 299);
            this.TxtIdPhone.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.TxtIdPhone.MaxLength = 20;
            this.TxtIdPhone.Name = "TxtIdPhone";
            this.TxtIdPhone.Size = new System.Drawing.Size(320, 50);
            this.TxtIdPhone.TabIndex = 9;
            // 
            // BtnPasswordFind
            // 
            this.BtnPasswordFind.BackColor = System.Drawing.SystemColors.Highlight;
            this.BtnPasswordFind.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPasswordFind.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnPasswordFind.ForeColor = System.Drawing.Color.White;
            this.BtnPasswordFind.Location = new System.Drawing.Point(619, 609);
            this.BtnPasswordFind.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.BtnPasswordFind.Name = "BtnPasswordFind";
            this.BtnPasswordFind.Size = new System.Drawing.Size(165, 232);
            this.BtnPasswordFind.TabIndex = 10;
            this.BtnPasswordFind.Text = "검색";
            this.BtnPasswordFind.UseVisualStyleBackColor = false;
            this.BtnPasswordFind.Click += new System.EventHandler(this.BtnPasswordFind_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label6.Location = new System.Drawing.Point(252, 492);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(333, 65);
            this.label6.TabIndex = 11;
            this.label6.Text = "비밀번호 찾기";
            // 
            // TxtIdResult
            // 
            this.TxtIdResult.BackColor = System.Drawing.Color.White;
            this.TxtIdResult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtIdResult.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtIdResult.ForeColor = System.Drawing.Color.OrangeRed;
            this.TxtIdResult.Location = new System.Drawing.Point(84, 393);
            this.TxtIdResult.Multiline = true;
            this.TxtIdResult.Name = "TxtIdResult";
            this.TxtIdResult.ReadOnly = true;
            this.TxtIdResult.Size = new System.Drawing.Size(706, 42);
            this.TxtIdResult.TabIndex = 12;
            this.TxtIdResult.TabStop = false;
            this.TxtIdResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TxtPasswordResult
            // 
            this.TxtPasswordResult.BackColor = System.Drawing.Color.White;
            this.TxtPasswordResult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtPasswordResult.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TxtPasswordResult.ForeColor = System.Drawing.Color.OrangeRed;
            this.TxtPasswordResult.Location = new System.Drawing.Point(81, 873);
            this.TxtPasswordResult.Multiline = true;
            this.TxtPasswordResult.Name = "TxtPasswordResult";
            this.TxtPasswordResult.ReadOnly = true;
            this.TxtPasswordResult.Size = new System.Drawing.Size(706, 42);
            this.TxtPasswordResult.TabIndex = 13;
            this.TxtPasswordResult.TabStop = false;
            this.TxtPasswordResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TxtPwPhone
            // 
            this.TxtPwPhone.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtPwPhone.Location = new System.Drawing.Point(265, 786);
            this.TxtPwPhone.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.TxtPwPhone.MaxLength = 20;
            this.TxtPwPhone.Name = "TxtPwPhone";
            this.TxtPwPhone.Size = new System.Drawing.Size(320, 50);
            this.TxtPwPhone.TabIndex = 17;
            // 
            // TxtPwName
            // 
            this.TxtPwName.BackColor = System.Drawing.SystemColors.Window;
            this.TxtPwName.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtPwName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TxtPwName.Location = new System.Drawing.Point(265, 700);
            this.TxtPwName.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.TxtPwName.MaxLength = 5;
            this.TxtPwName.Name = "TxtPwName";
            this.TxtPwName.Size = new System.Drawing.Size(320, 50);
            this.TxtPwName.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(84, 789);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 45);
            this.label3.TabIndex = 15;
            this.label3.Text = "전화번호";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(152, 702);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 45);
            this.label7.TabIndex = 14;
            this.label7.Text = "이름";
            // 
            // FrmFind
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 45F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(870, 1009);
            this.Controls.Add(this.TxtPwPhone);
            this.Controls.Add(this.TxtPwName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TxtPasswordResult);
            this.Controls.Add(this.TxtIdResult);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.BtnPasswordFind);
            this.Controls.Add(this.TxtIdPhone);
            this.Controls.Add(this.TxtPwId);
            this.Controls.Add(this.TxtIdName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnIdFind);
            this.Font = new System.Drawing.Font("맑은 고딕", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmFind";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "아이디 / 비밀번호 찾기";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnIdFind;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox TxtIdName;
        public System.Windows.Forms.TextBox TxtPwId;
        public System.Windows.Forms.TextBox TxtIdPhone;
        private System.Windows.Forms.Button BtnPasswordFind;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TxtIdResult;
        private System.Windows.Forms.TextBox TxtPasswordResult;
        public System.Windows.Forms.TextBox TxtPwPhone;
        public System.Windows.Forms.TextBox TxtPwName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
    }
}