﻿using GameBox.Member;
using System;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmJoin : Form
    {
        MemberDTO member = new MemberDTO();
        MemberDAO memberDAO = new MemberDAO();

        public FrmJoin()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnJoin_Click(object sender, EventArgs e)
        {
            //빈 값이 없으면 가입 가능
            if (CheckValidation())
            {
                member.Id = TxtId.Text;
                member.Password = TxtPassword.Text;
                member.Name = TxtName.Text;
                member.Phone = TxtPhone.Text;
                memberDAO.member = member;
                memberDAO.isNew = true;
                memberDAO.SaveData();
                ClearInputs();
            }
        }

        //빈값 예외처리
        private bool CheckValidation()
        {
            if (string.IsNullOrEmpty(TxtId.Text) ||
                string.IsNullOrEmpty(TxtPassword.Text) || 
                string.IsNullOrEmpty(TxtName.Text) || 
                string.IsNullOrEmpty(TxtPhone.Text))
            {
                MessageBox.Show("빈값은 처리할 수 없습니다.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        //빈 값 만들기
        private void ClearInputs()
        {
            TxtId.Text = TxtPassword.Text = TxtName.Text = TxtPhone.Text = "";
        }
    }
}
