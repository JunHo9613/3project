﻿using GameBox.Member;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmFind : Form
    {
        MemberDAO memberDAO = new MemberDAO();
        List<MemberDTO> memberList = new List<MemberDTO>();

        public FrmFind()
        {
            memberDAO.SearchAll();
            memberList = memberDAO.memberList;
            InitializeComponent();
        }

        private void BtnIdFind_Click(object sender, EventArgs e)
        {
            int cnt = 0;

            if (string.IsNullOrEmpty(TxtIdName.Text) ||
                string.IsNullOrEmpty(TxtIdPhone.Text))
            {
                MessageBox.Show("빈값은 처리할 수 없습니다.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                foreach (var member in memberList)
                {
                    if (member.Name.Equals(TxtIdName.Text) && 
                        member.Phone.Equals(TxtIdPhone.Text))
                    {
                        TxtIdResult.Text = TxtIdName.Text + "님의 아이디는 [" + member.Id + "] 입니다.";
                        break;
                    }
                    cnt++;
                }


                if(cnt == memberList.Count)
                {
                    TxtIdResult.Text = "존재하지 않는 회원 입니다. 회원가입 해주세요.";
                }
            }
        }

        private void BtnPasswordFind_Click(object sender, EventArgs e)
        {
            int cnt = 0;

            if (string.IsNullOrEmpty(TxtPwId.Text) ||
                string.IsNullOrEmpty(TxtPwName.Text) ||
                string.IsNullOrEmpty(TxtPwPhone.Text))
            {
                MessageBox.Show("빈값은 처리할 수 없습니다.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                foreach (var member in memberList)
                {
                    if (member.Id.Equals(TxtPwId.Text) && 
                        member.Name.Equals(TxtPwName.Text) && 
                        member.Phone.Equals(TxtPwPhone.Text))
                    {
                        TxtPasswordResult.Text = TxtIdName.Text + "님의 비밀번호는 [" + member.Password + "] 입니다.";
                        break;
                    }
                    cnt++;
                }

                if (cnt == memberList.Count)
                {
                    TxtPasswordResult.Text = "존재하지 않는 회원 입니다. 회원가입 해주세요.";
                }
            }
        }
    }
}
