﻿
namespace GameBox
{
    partial class FrmMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MnuMember = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuMemberInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuMemberUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuMemberDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.회원리스트LToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuMulti = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuSingle = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuSingleIndian = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuSingleCookie = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuSingleSnake = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuHistory = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuHistoryIndian = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuHistoryCookie = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuMember,
            this.MnuMulti,
            this.MnuSingle,
            this.MnuHistory,
            this.MnuExit});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(1286, 42);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MnuMember
            // 
            this.MnuMember.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuMemberInfo,
            this.MnuMemberUpdate,
            this.MnuMemberDelete,
            this.회원리스트LToolStripMenuItem});
            this.MnuMember.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MnuMember.Name = "MnuMember";
            this.MnuMember.Size = new System.Drawing.Size(184, 36);
            this.MnuMember.Text = "마이페이지(&M)";
            // 
            // MnuMemberInfo
            // 
            this.MnuMemberInfo.Name = "MnuMemberInfo";
            this.MnuMemberInfo.Size = new System.Drawing.Size(269, 36);
            this.MnuMemberInfo.Text = "내 정보 보기(&I)";
            this.MnuMemberInfo.Click += new System.EventHandler(this.MnuMemberInfo_Click);
            // 
            // MnuMemberUpdate
            // 
            this.MnuMemberUpdate.Name = "MnuMemberUpdate";
            this.MnuMemberUpdate.Size = new System.Drawing.Size(269, 36);
            this.MnuMemberUpdate.Text = "내 정보 수정(&U)";
            this.MnuMemberUpdate.Click += new System.EventHandler(this.MnuMemberUpdate_Click);
            // 
            // MnuMemberDelete
            // 
            this.MnuMemberDelete.Name = "MnuMemberDelete";
            this.MnuMemberDelete.Size = new System.Drawing.Size(269, 36);
            this.MnuMemberDelete.Text = "회원탈퇴(&D)";
            this.MnuMemberDelete.Click += new System.EventHandler(this.MnuMemberDelete_Click);
            // 
            // 회원리스트LToolStripMenuItem
            // 
            this.회원리스트LToolStripMenuItem.Name = "회원리스트LToolStripMenuItem";
            this.회원리스트LToolStripMenuItem.Size = new System.Drawing.Size(269, 36);
            this.회원리스트LToolStripMenuItem.Text = "회원리스트(&L)";
            this.회원리스트LToolStripMenuItem.Click += new System.EventHandler(this.회원리스트LToolStripMenuItem_Click);
            // 
            // MnuMulti
            // 
            this.MnuMulti.Name = "MnuMulti";
            this.MnuMulti.Size = new System.Drawing.Size(168, 36);
            this.MnuMulti.Text = "멀티 게임(&M)";
            this.MnuMulti.Click += new System.EventHandler(this.MnuMulti_Click);
            // 
            // MnuSingle
            // 
            this.MnuSingle.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuSingleIndian,
            this.MnuSingleCookie,
            this.MnuSingleSnake});
            this.MnuSingle.Name = "MnuSingle";
            this.MnuSingle.Size = new System.Drawing.Size(151, 36);
            this.MnuSingle.Text = "싱글게임(&S)";
            // 
            // MnuSingleIndian
            // 
            this.MnuSingleIndian.Name = "MnuSingleIndian";
            this.MnuSingleIndian.Size = new System.Drawing.Size(250, 36);
            this.MnuSingleIndian.Text = "인디언 포커(&I)";
            this.MnuSingleIndian.Click += new System.EventHandler(this.MnuSingleIndian_Click);
            // 
            // MnuSingleCookie
            // 
            this.MnuSingleCookie.Name = "MnuSingleCookie";
            this.MnuSingleCookie.Size = new System.Drawing.Size(250, 36);
            this.MnuSingleCookie.Text = "쿠키런(&C)";
            this.MnuSingleCookie.Click += new System.EventHandler(this.MnuSingleCookie_Click);
            // 
            // MnuSingleSnake
            // 
            this.MnuSingleSnake.Name = "MnuSingleSnake";
            this.MnuSingleSnake.Size = new System.Drawing.Size(250, 36);
            this.MnuSingleSnake.Text = "스네이크(&S)";
            this.MnuSingleSnake.Click += new System.EventHandler(this.MnuSingleSnake_Click);
            // 
            // MnuHistory
            // 
            this.MnuHistory.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuHistoryIndian,
            this.MnuHistoryCookie});
            this.MnuHistory.Name = "MnuHistory";
            this.MnuHistory.Size = new System.Drawing.Size(155, 36);
            this.MnuHistory.Text = "게임전적(&H)";
            // 
            // MnuHistoryIndian
            // 
            this.MnuHistoryIndian.Name = "MnuHistoryIndian";
            this.MnuHistoryIndian.Size = new System.Drawing.Size(250, 36);
            this.MnuHistoryIndian.Text = "인디언 포커(&I)";
            this.MnuHistoryIndian.Click += new System.EventHandler(this.MnuHistoryIndian_Click);
            // 
            // MnuHistoryCookie
            // 
            this.MnuHistoryCookie.Name = "MnuHistoryCookie";
            this.MnuHistoryCookie.Size = new System.Drawing.Size(250, 36);
            this.MnuHistoryCookie.Text = "쿠키런(&C)";
            this.MnuHistoryCookie.Click += new System.EventHandler(this.MnuHistoryCookie_Click);
            // 
            // MnuExit
            // 
            this.MnuExit.Name = "MnuExit";
            this.MnuExit.Size = new System.Drawing.Size(104, 36);
            this.MnuExit.Text = "종료(&X)";
            this.MnuExit.Click += new System.EventHandler(this.MnuExit_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1286, 940);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmMain";
            this.Text = "GameBox";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Shown += new System.EventHandler(this.FrmMain_Shown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MnuMember;
        private System.Windows.Forms.ToolStripMenuItem MnuMemberInfo;
        private System.Windows.Forms.ToolStripMenuItem MnuMemberUpdate;
        private System.Windows.Forms.ToolStripMenuItem MnuMemberDelete;
        private System.Windows.Forms.ToolStripMenuItem MnuMulti;
        private System.Windows.Forms.ToolStripMenuItem MnuHistory;
        private System.Windows.Forms.ToolStripMenuItem MnuHistoryIndian;
        private System.Windows.Forms.ToolStripMenuItem MnuHistoryCookie;
        private System.Windows.Forms.ToolStripMenuItem MnuExit;
        private System.Windows.Forms.ToolStripMenuItem 회원리스트LToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MnuSingle;
        private System.Windows.Forms.ToolStripMenuItem MnuSingleIndian;
        private System.Windows.Forms.ToolStripMenuItem MnuSingleCookie;
        private System.Windows.Forms.ToolStripMenuItem MnuSingleSnake;
    }
}