﻿
namespace GameBox
{
    partial class FrmWaitingRoom
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbLog = new System.Windows.Forms.ListBox();
            this.TxtSendMsg = new System.Windows.Forms.TextBox();
            this.BtnIndianReady = new System.Windows.Forms.Button();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.BtnCookieReady = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.LvConnect = new System.Windows.Forms.ListView();
            this.columnHeader_Idx = new System.Windows.Forms.ColumnHeader();
            this.columnHeader_ID = new System.Windows.Forms.ColumnHeader();
            this.columnHeader_Name = new System.Windows.Forms.ColumnHeader();
            this.columnHeader_State = new System.Windows.Forms.ColumnHeader();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TxtCookieRun = new System.Windows.Forms.TextBox();
            this.TxtIndianPoker = new System.Windows.Forms.TextBox();
            this.matchingTimer = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.lbLog);
            this.groupBox1.Controls.Add(this.TxtSendMsg);
            this.groupBox1.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(12, 84);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(134, 748);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "전체채팅";
            // 
            // lbLog
            // 
            this.lbLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbLog.BackColor = System.Drawing.Color.AliceBlue;
            this.lbLog.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbLog.FormattingEnabled = true;
            this.lbLog.HorizontalScrollbar = true;
            this.lbLog.ItemHeight = 38;
            this.lbLog.Location = new System.Drawing.Point(13, 44);
            this.lbLog.Name = "lbLog";
            this.lbLog.Size = new System.Drawing.Size(106, 612);
            this.lbLog.TabIndex = 11;
            // 
            // TxtSendMsg
            // 
            this.TxtSendMsg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtSendMsg.BackColor = System.Drawing.Color.Azure;
            this.TxtSendMsg.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtSendMsg.Location = new System.Drawing.Point(13, 681);
            this.TxtSendMsg.Name = "TxtSendMsg";
            this.TxtSendMsg.Size = new System.Drawing.Size(106, 45);
            this.TxtSendMsg.TabIndex = 12;
            this.TxtSendMsg.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TxtSendMsg_KeyDown);
            // 
            // BtnIndianReady
            // 
            this.BtnIndianReady.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnIndianReady.BackColor = System.Drawing.Color.DarkOrange;
            this.BtnIndianReady.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnIndianReady.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnIndianReady.ForeColor = System.Drawing.Color.White;
            this.BtnIndianReady.Location = new System.Drawing.Point(477, 483);
            this.BtnIndianReady.Name = "BtnIndianReady";
            this.BtnIndianReady.Size = new System.Drawing.Size(481, 53);
            this.BtnIndianReady.TabIndex = 16;
            this.BtnIndianReady.Text = "Ready";
            this.BtnIndianReady.UseVisualStyleBackColor = false;
            this.BtnIndianReady.Click += new System.EventHandler(this.BtnIndianReady_Click);
            // 
            // BtnCancel
            // 
            this.BtnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnCancel.BackColor = System.Drawing.Color.Gray;
            this.BtnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCancel.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCancel.ForeColor = System.Drawing.Color.White;
            this.BtnCancel.Location = new System.Drawing.Point(11, 666);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(482, 53);
            this.BtnCancel.TabIndex = 15;
            this.BtnCancel.Text = "Cancel";
            this.BtnCancel.UseVisualStyleBackColor = false;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BtnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnExit.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnExit.ForeColor = System.Drawing.Color.White;
            this.BtnExit.Location = new System.Drawing.Point(477, 665);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(481, 53);
            this.BtnExit.TabIndex = 14;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // BtnCookieReady
            // 
            this.BtnCookieReady.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnCookieReady.BackColor = System.Drawing.Color.DarkOrange;
            this.BtnCookieReady.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCookieReady.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCookieReady.ForeColor = System.Drawing.Color.White;
            this.BtnCookieReady.Location = new System.Drawing.Point(477, 574);
            this.BtnCookieReady.Name = "BtnCookieReady";
            this.BtnCookieReady.Size = new System.Drawing.Size(481, 53);
            this.BtnCookieReady.TabIndex = 13;
            this.BtnCookieReady.Text = "Ready";
            this.BtnCookieReady.UseVisualStyleBackColor = false;
            this.BtnCookieReady.Click += new System.EventHandler(this.BtnCookieReady_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(23, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "게임 대기실";
            // 
            // LvConnect
            // 
            this.LvConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LvConnect.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_Idx,
            this.columnHeader_ID,
            this.columnHeader_Name,
            this.columnHeader_State});
            this.LvConnect.HideSelection = false;
            this.LvConnect.Location = new System.Drawing.Point(11, 34);
            this.LvConnect.Name = "LvConnect";
            this.LvConnect.Size = new System.Drawing.Size(947, 420);
            this.LvConnect.TabIndex = 9;
            this.LvConnect.UseCompatibleStateImageBehavior = false;
            this.LvConnect.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader_Idx
            // 
            this.columnHeader_Idx.Text = "No.";
            this.columnHeader_Idx.Width = 100;
            // 
            // columnHeader_ID
            // 
            this.columnHeader_ID.Text = "ID";
            this.columnHeader_ID.Width = 250;
            // 
            // columnHeader_Name
            // 
            this.columnHeader_Name.Text = "Name";
            this.columnHeader_Name.Width = 250;
            // 
            // columnHeader_State
            // 
            this.columnHeader_State.Text = "State";
            this.columnHeader_State.Width = 340;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.TxtCookieRun);
            this.groupBox2.Controls.Add(this.TxtIndianPoker);
            this.groupBox2.Controls.Add(this.BtnCancel);
            this.groupBox2.Controls.Add(this.BtnIndianReady);
            this.groupBox2.Controls.Add(this.BtnExit);
            this.groupBox2.Controls.Add(this.LvConnect);
            this.groupBox2.Controls.Add(this.BtnCookieReady);
            this.groupBox2.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(152, 84);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(966, 748);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "접속자 목록";
            // 
            // TxtCookieRun
            // 
            this.TxtCookieRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtCookieRun.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.TxtCookieRun.ForeColor = System.Drawing.Color.White;
            this.TxtCookieRun.Location = new System.Drawing.Point(11, 574);
            this.TxtCookieRun.Multiline = true;
            this.TxtCookieRun.Name = "TxtCookieRun";
            this.TxtCookieRun.ReadOnly = true;
            this.TxtCookieRun.Size = new System.Drawing.Size(481, 53);
            this.TxtCookieRun.TabIndex = 18;
            this.TxtCookieRun.TabStop = false;
            this.TxtCookieRun.Text = "쿠키런";
            this.TxtCookieRun.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TxtIndianPoker
            // 
            this.TxtIndianPoker.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtIndianPoker.BackColor = System.Drawing.Color.DarkRed;
            this.TxtIndianPoker.ForeColor = System.Drawing.Color.White;
            this.TxtIndianPoker.Location = new System.Drawing.Point(11, 483);
            this.TxtIndianPoker.Multiline = true;
            this.TxtIndianPoker.Name = "TxtIndianPoker";
            this.TxtIndianPoker.ReadOnly = true;
            this.TxtIndianPoker.Size = new System.Drawing.Size(481, 53);
            this.TxtIndianPoker.TabIndex = 17;
            this.TxtIndianPoker.TabStop = false;
            this.TxtIndianPoker.Text = "인디언 포커";
            this.TxtIndianPoker.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FrmWaitingRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1130, 844);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FrmWaitingRoom";
            this.Text = "게임 대기실";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmWaitingRoom_FormClosed);
            this.Load += new System.EventHandler(this.FrmWaitingRoom_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView LvConnect;
        private System.Windows.Forms.ColumnHeader columnHeader_Idx;
        private System.Windows.Forms.ColumnHeader columnHeader_ID;
        private System.Windows.Forms.ColumnHeader columnHeader_Name;
        private System.Windows.Forms.ColumnHeader columnHeader_State;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Button BtnCookieReady;
        private System.Windows.Forms.ListBox lbLog;
        private System.Windows.Forms.TextBox TxtSendMsg;
        private System.Windows.Forms.Button BtnIndianReady;
        private System.Windows.Forms.TextBox TxtIndianPoker;
        private System.Windows.Forms.TextBox TxtCookieRun;
        private System.Windows.Forms.Timer matchingTimer;
    }
}

