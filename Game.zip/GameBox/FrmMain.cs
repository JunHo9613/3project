﻿using GameBox.Member;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmMain : Form
    {
        public string strId;
        MemberDAO memberDAO = new MemberDAO();
        List<MemberDTO> memberList = new List<MemberDTO>();

        // 회원 관련 폼
        FrmLogin frmLogin = null;
        FrmMember frmMember = null;
        FrmMemberUp frmMemberUpdate = null;
        FrmMemberList frmMemberList = null;

        // 게임 관련 폼
        FrmWaitingRoom frmWaitingRoom = null;
        FrmCookieRun frmCookie = null;
        FrmSnake frmSnake = null;

        // 게임 전적 폼
        FrmHistoryList frmIndianHistory = null;
        FrmHistoryList frmCookieHistory = null;


        /**********************             기본               ********************/

        public FrmMain()
        {
            InitializeComponent();
        }

        //실행 되자 마자 로그인
        private void FrmMain_Shown(object sender, EventArgs e)
        {
            frmLogin = new FrmLogin();
            frmLogin.Owner = this;
            frmLogin.ShowDialog();
        }

        //자식 폼 설정
        private void InitChildForm(Form frm, string strTitle)
        {
            frm.Text = strTitle;
            frm.Dock = DockStyle.Fill;
            frm.MdiParent = this; // FrmMain
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Width = this.ClientSize.Width - 1000;       // 추가
            frm.Height = this.Height - menuStrip1.Height;   // 추가
            frm.Show();
            frm.WindowState = FormWindowState.Maximized;
        }



        /**********************             종료               ********************/


        //닫기 버튼 예외처리
        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            ExitMsg();
        }
        
        //종료
        private void MnuExit_Click(object sender, EventArgs e)
        {
            ExitMsg();
        }

        //종료
        private void ExitMsg()
        {
            if (MessageBox.Show(this, "종료하시겠습니까?", "종료", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                memberDAO.SearchAll();
                memberList = memberDAO.memberList;
                foreach(var m in memberList)
                {
                    m.State = "오프라인";
                    m.IsConnect = "false";
                    memberDAO.member = m;
                    memberDAO.UpdateState();
                    memberDAO.UpdateConnect();
                }
                Environment.Exit(0);
            }
        }

        /**********************             회원               ********************/


        //내 정보 보기
        private void MnuMemberInfo_Click(object sender, EventArgs e)
        {
            if(frmMember == null || frmMember.IsDisposed)
            {
                frmMember = new FrmMember(strId);
                frmMember.ShowDialog();
                //InitChildForm(frmMember, "회원 정보 보기");
            }
        }
        
        //내 정보 수정
        private void MnuMemberUpdate_Click(object sender, EventArgs e)
        {
            if (frmMemberUpdate == null || frmMemberUpdate.IsDisposed)
            {
                frmMemberUpdate = new FrmMemberUp(strId);
                frmMemberUpdate.ShowDialog();
                //InitChildForm(frmMemberUpdate, "회원 정보 수정");
            }
        }
        
        //회원 탈퇴
        private void MnuMemberDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "탈퇴 하시겠습니까?", "탈퇴", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                memberDAO.SearchId(strId);
                memberDAO.Delete();
                Environment.Exit(0);
            } 
        }
        
        //회원리스트
        private void 회원리스트LToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmMemberList == null || frmMemberList.IsDisposed)
            {
                frmMemberList = new FrmMemberList();
                InitChildForm(frmMemberList, "전체 회원 목록");
            }
        }


        /**********************           멀티게임              ********************/


        //멀티 게임
        private void MnuMulti_Click(object sender, EventArgs e)
        {
            if (frmWaitingRoom == null || frmWaitingRoom.IsDisposed)
            {
                frmWaitingRoom = new FrmWaitingRoom(strId);
                InitChildForm(frmWaitingRoom, "게임 대기실");
            }
        }


        /**********************          싱글게임             ********************/



        private void MnuSingleIndian_Click(object sender, EventArgs e)
        {

        }

        private void MnuSingleCookie_Click(object sender, EventArgs e)
        {
            if (frmCookie == null || frmCookie.IsDisposed)
            {
                frmCookie = new FrmCookieRun();
                frmCookie.ShowDialog();
                //InitChildForm(frmCookie, "싱글게임-쿠키런");
            }
        }

        private void MnuSingleSnake_Click(object sender, EventArgs e)
        {
            if (frmSnake == null || frmSnake.IsDisposed)
            {
                frmSnake = new FrmSnake();
                frmSnake.ShowDialog();
                //InitChildForm(frmSnake, "싱글게임-스네이크");
            }
        }



        /**********************             전적                ********************/

        //인디언포커 전적
        private void MnuHistoryIndian_Click(object sender, EventArgs e)
        {
            if (frmIndianHistory == null || frmIndianHistory.IsDisposed)
            {
                frmIndianHistory = new FrmHistoryList("인디언 포커");
                InitChildForm(frmIndianHistory, "인디언 포커 전적 목록");
            }
        }

        //쿠키런 전적
        private void MnuHistoryCookie_Click(object sender, EventArgs e)
        {
            if (frmCookieHistory == null || frmCookieHistory.IsDisposed)
            {
                frmCookieHistory = new FrmHistoryList("쿠키런");
                InitChildForm(frmCookieHistory, "쿠키런 전적 목록");
            }
        }
    }
}
