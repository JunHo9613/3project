﻿
namespace GameBox
{
    partial class FrmHistoryList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lv_table = new System.Windows.Forms.ListView();
            this.column_Idx = new System.Windows.Forms.ColumnHeader();
            this.column_Title = new System.Windows.Forms.ColumnHeader();
            this.column_Player1_Id = new System.Windows.Forms.ColumnHeader();
            this.column_Player1_StartMoney = new System.Windows.Forms.ColumnHeader();
            this.column_Player1_Score = new System.Windows.Forms.ColumnHeader();
            this.column_Player1_LastMoney = new System.Windows.Forms.ColumnHeader();
            this.column_Player2_Id = new System.Windows.Forms.ColumnHeader();
            this.column_Player2_StartMoney = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2_Player2_Score = new System.Windows.Forms.ColumnHeader();
            this.column_Player2_LastMoney = new System.Windows.Forms.ColumnHeader();
            this.column_Winner = new System.Windows.Forms.ColumnHeader();
            this.column_GameDate = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // lv_table
            // 
            this.lv_table.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lv_table.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.column_Idx,
            this.column_Title,
            this.column_Player1_Id,
            this.column_Player1_StartMoney,
            this.column_Player1_Score,
            this.column_Player1_LastMoney,
            this.column_Player2_Id,
            this.column_Player2_StartMoney,
            this.columnHeader2_Player2_Score,
            this.column_Player2_LastMoney,
            this.column_Winner,
            this.column_GameDate});
            this.lv_table.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lv_table.FullRowSelect = true;
            this.lv_table.GridLines = true;
            this.lv_table.HideSelection = false;
            this.lv_table.Location = new System.Drawing.Point(33, 35);
            this.lv_table.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lv_table.Name = "lv_table";
            this.lv_table.Size = new System.Drawing.Size(1145, 814);
            this.lv_table.TabIndex = 0;
            this.lv_table.UseCompatibleStateImageBehavior = false;
            this.lv_table.View = System.Windows.Forms.View.Details;
            // 
            // column_Idx
            // 
            this.column_Idx.Text = "Idx";
            this.column_Idx.Width = 100;
            // 
            // column_Title
            // 
            this.column_Title.Text = "GameTitle";
            this.column_Title.Width = 250;
            // 
            // column_Player1_Id
            // 
            this.column_Player1_Id.Text = "Player1_Id";
            this.column_Player1_Id.Width = 200;
            // 
            // column_Player1_StartMoney
            // 
            this.column_Player1_StartMoney.Text = "Player1_StartMoney";
            this.column_Player1_StartMoney.Width = 300;
            // 
            // column_Player1_Score
            // 
            this.column_Player1_Score.Width = 200;
            // 
            // column_Player1_LastMoney
            // 
            this.column_Player1_LastMoney.Text = "Player1_LastMoney";
            this.column_Player1_LastMoney.Width = 300;
            // 
            // column_Player2_Id
            // 
            this.column_Player2_Id.Text = "Player2_Id";
            this.column_Player2_Id.Width = 200;
            // 
            // column_Player2_StartMoney
            // 
            this.column_Player2_StartMoney.Text = "Player2_StartMoney";
            this.column_Player2_StartMoney.Width = 300;
            // 
            // columnHeader2_Player2_Score
            // 
            this.columnHeader2_Player2_Score.Text = "Player2_Score";
            this.columnHeader2_Player2_Score.Width = 200;
            // 
            // column_Player2_LastMoney
            // 
            this.column_Player2_LastMoney.Text = "Player2_LastMoney";
            this.column_Player2_LastMoney.Width = 300;
            // 
            // column_Winner
            // 
            this.column_Winner.Text = "Winner";
            this.column_Winner.Width = 200;
            // 
            // column_GameDate
            // 
            this.column_GameDate.Text = "GameDate";
            this.column_GameDate.Width = 300;
            // 
            // FrmHistoryList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1183, 862);
            this.Controls.Add(this.lv_table);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmHistoryList";
            this.Text = "FrmMemberList";
            this.Load += new System.EventHandler(this.FrmMemberList_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lv_table;
        private System.Windows.Forms.ColumnHeader column_Idx;
        private System.Windows.Forms.ColumnHeader column_Title;
        private System.Windows.Forms.ColumnHeader column_Player1_Id;
        private System.Windows.Forms.ColumnHeader column_Player1_StartMoney;
        private System.Windows.Forms.ColumnHeader column_Player1_LastMoney;
        private System.Windows.Forms.ColumnHeader column_Player2_Id;
        private System.Windows.Forms.ColumnHeader column_Winner;
        private System.Windows.Forms.ColumnHeader column_Player2_StartMoney;
        private System.Windows.Forms.ColumnHeader column_Player2_LastMoney;
        private System.Windows.Forms.ColumnHeader column_GameDate;
        private System.Windows.Forms.ColumnHeader column_Player1_Score;
        private System.Windows.Forms.ColumnHeader columnHeader2_Player2_Score;
    }
}