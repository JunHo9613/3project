﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmCookieRun : Form
    {
        Stopwatch sw = new();
        Random rand = new Random();
        Timer timer = new();
        private int cookie_Behavior = 0;
        private int cookieY = 200, backgroundX = 0;
        private int jump_Cnt, background_Cnt = 1;
        private int background_Category, speed = 10;
        private int random, obstacle_Speed = 50;
        private int[] obstacleX_Category = new int[] { 1500, 1500, 1500 };
        private int obstacle_Number;
        private int score = 0;
        private int monster = 0;
        private int time;
        private string[] cookie = new string[] {"../../../CookieImg/RM1.png", "../../../CookieImg/RM2.png", "../../../CookieImg/RM3.png", "../../../CookieImg/RM4.png",
                                                "../../../CookieImg/RM5.png", "../../../CookieImg/RM6.png", "../../../CookieImg/RM7.png", "../../../CookieImg/RM8.png", };
        private string[] back = new string[] { "../../../CookieImg/긴 배경1.jpg", "../../../CookieImg/긴 배경2.jpg", "../../../CookieImg/긴 배경3.jpg" };
        private bool sec = false;
        private bool jump_Top = false;
        private bool jump = false;
        private bool obstacle = true;
        private bool gameover = false;
        private bool abc = false;
        private bool score_bool = false;
        public FrmCookieRun()
        {
            InitializeComponent();
            this.BackColor = Color.White;
            this.Paint += Form1_Paint;
            timer.Interval = 10;
            timer.Tick += Timer_Tick;
            this.KeyDown += Form1_KeyDown;
            sw.Start();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (gameover == false)
            {
                if (jump_Cnt == 2)
                {

                }
                else if (e.KeyCode == Keys.Space)
                {
                    jump = true;
                    jump_Cnt++;
                }
            }
            else if (gameover)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    gameover = false;
                    cookie_Behavior = 0;
                    cookieY = 200;
                    backgroundX = 0;
                    jump_Cnt = 0;
                    background_Cnt = 0;
                    background_Category = 0;
                    speed = 10;
                    obstacle = true;
                    obstacleX_Category[0] = 1500;
                    obstacleX_Category[1] = 1500;
                    obstacleX_Category[2] = 1500;
                    obstacle_Speed = 50;
                    sec = false;
                    sw.Reset();
                    sw.Start();
                }
            }
            Invalidate();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (gameover == false)
            {
                if (score_bool == false)
                {

                    if ((sw.ElapsedMilliseconds / 1000) % 10 == 0)
                    {
                        time = (int)sw.ElapsedMilliseconds / 1000;
                        if (sw.ElapsedMilliseconds / 1000 == 0)
                        {

                        }
                        else
                        {
                            score_bool = true;
                            score++;
                        }
                    }
                }
                if(sw.ElapsedMilliseconds/1000 == time + 1)
                {
                    score_bool = false;
                }
                this.Text = $"{score}점";
                cookie_Behavior++;
                random = rand.Next(obstacleX_Category.Length + 1);
                if (obstacleX_Category[0] <= 0 || obstacleX_Category[1] <= 0 || obstacleX_Category[2] <= 0)
                {
                    obstacleX_Category[0] = 1500;
                    obstacleX_Category[1] = 1500;
                    obstacleX_Category[2] = 1500;
                    obstacle = true;
                    sec = false;
                    score++;
                    monster++;
                }

                if (obstacle)
                {
                    if (random == 0)
                    {
                    }
                    else if (random == 1)
                    {
                        obstacle_Number = 0;
                        obstacle = false;
                    }
                    else if (random == 2)
                    {
                        obstacle_Number = 1;
                        obstacle = false;
                    }
                    else if (random == 3)
                    {
                        obstacle_Number = 2;
                        obstacle = false;
                    }
                }
                obstacleX_Category[obstacle_Number] -= obstacle_Speed;
                if (sec == false)
                {
                    if ((obstacleX_Category[0] <= 150 && cookieY == 200) ||
                        (obstacleX_Category[1] <= 150 && (cookieY <= 200 && cookieY >= 100)) || 
                        (obstacleX_Category[2] <= 150 && cookieY <= 100))
                    {
                        sec = true;
                        gameover = true;
                        sw.Stop();
                    }
                    else if ((obstacleX_Category[0] <= 150 && cookieY != 200) ||
                        (obstacleX_Category[1] <= 150 && (cookieY >= 200 && cookieY <= 100)) ||
                        (obstacleX_Category[2] <= 150 && cookieY >= 100))
                    {
                        sec = true;
                    }
                 }

                if (backgroundX <= 1400)
                {
                    backgroundX += speed;
                }
                else
                {
                    backgroundX = 0;
                    background_Category++;
                    background_Cnt++;
                }

                if (background_Category == back.Length)
                {
                    background_Category = 0;
                }
                if (abc == false)
                {
                    if (background_Cnt % 5 == 0)
                    {
                        speed += 10;
                        obstacle_Speed += 10;
                        abc = true;
                    }
                }
                else if(background_Cnt % 5 != 0)
                {
                    abc = false;
                }
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine($"쿠키 행동 : {cookie_Behavior}, 쿠키 Y좌표 : {cookieY}, 점프 횟수 : {jump_Cnt}, 점프 했는지 : {jump}, 최대 높이에 도달 했는지 : {jump_Top}");
                Console.WriteLine($"배경 순서 : {background_Category}, 배경 X좌표 : {backgroundX}, 지나간 배경 수 : {background_Cnt}, 배경 속도 : {speed}");
                Console.WriteLine($"바위 X좌표 : {obstacleX_Category[0]}, 석탑 X좌표 : {obstacleX_Category[1]}, 새 X좌표 : {obstacleX_Category[2]} ");
                Console.WriteLine($"장애물 뭐 나오는지 : {obstacle_Number}, 장애물 속도 {obstacle_Speed}, 장애물이 안나와있는지 : {obstacle}");
                Console.WriteLine($"게임 오버 했는지 : {gameover}, sec : {sec}, 점수 : {score}, 시간 : {sw.ElapsedMilliseconds/1000}, 피한 몬스터 : {monster}");
                Console.WriteLine($"점수 : {score_bool}, 시간 저장 : {time}");
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                if (jump)
                {
                    cookieY -= 70;
                    if (cookieY <= 200 - (jump_Cnt * 100))
                    {
                        jump = false;
                        jump_Top = true;
                    }
                }

                if (jump_Top)
                {
                    cookieY += 20;
                    if (cookieY >= 200)
                    {
                        cookieY = 200;
                        jump_Top = false;
                        jump_Cnt = 0;
                    }
                }

                Invalidate();
                if (cookie_Behavior >= 8)
                    cookie_Behavior = 0;
            }

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

            Image backGround = Image.FromFile(back[background_Category]);
            Image stone = Image.FromFile("../../../CookieImg/바위.jpg");
            Image pagoda = Image.FromFile("../../../CookieImg/석탑.png");
            Image bird = Image.FromFile("../../../CookieImg/새.png");
            Rectangle rect = new(backgroundX, 0, 1400, 700);
            e.Graphics.DrawImage(backGround, 0, 0, rect, GraphicsUnit.Pixel);
            rect = new(0, 0, 150, 100);
            e.Graphics.DrawImage(stone, obstacleX_Category[0], 450, rect, GraphicsUnit.Pixel);
            rect = new(0, 0, 300, 378);
            e.Graphics.DrawImage(pagoda, obstacleX_Category[1], 300, rect, GraphicsUnit.Pixel);
            rect = new(0, 0, 225, 225);
            e.Graphics.DrawImage(bird, obstacleX_Category[2], 100, rect, GraphicsUnit.Pixel);
            Font font_sec = new("돋움", 50);
            e.Graphics.DrawString($"{sw.ElapsedMilliseconds/1000}초", font_sec, Brushes.AntiqueWhite, 600, 100);
            try
            {
                Image image = Image.FromFile(cookie[cookie_Behavior]);
                timer.Start();
                e.Graphics.DrawImage(image, 0, cookieY);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            if (gameover)
            {
                Font font_GameOver = new("돋움", 50);
                e.Graphics.DrawString("GAME OVER", font_GameOver, Brushes.Black, 500, 300);
                Font font_score = new("돋움", 40);
                e.Graphics.DrawString($"점수 : {score}점", font_score, Brushes.White, 580, 400);
                Font f = new("돋움", 20);
                e.Graphics.DrawString("PRESS \"ENTER\" TO TRY AGAIN", f, Brushes.White, 500, 500);
            }
        }
    }
}
