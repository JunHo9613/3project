﻿using GameBox.GameHistory;
using GameBox.History;
using GameBox.Member;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmWaitingRoom : Form
    {
        MemberDTO member = new MemberDTO();
        MemberDTO other = new MemberDTO();
        MemberDAO memberDAO = new MemberDAO();
        public string strId { get; set; }
        public bool isGamming { get; set; }

        GameHistoryDTO history = new GameHistoryDTO();
        GameHistoryDAO historyDAO = new GameHistoryDAO();

        FrmMultiCookie frmMultiCookie = null;

        const string ip = "127.0.0.1";      //IP
        const int port = 9000;              //PORT

        Socket clientSocket;
        IPEndPoint ipep;

        Thread tRecv;
        bool isRecv;

        delegate void AddMsgLog(string log);
        AddMsgLog addMsgLog = null;

        public FrmWaitingRoom(string strId)
        {
            this.strId = strId;
            InitializeComponent();
            isGamming = false;
        }

        private void FrmWaitingRoom_Load(object sender, EventArgs e)
        {
            //채팅 시작 안내
            TxtSendMsg.Text = strId + "님 환영합니다. 엔터를 누르시면 채팅을 시작합니다.";

            //[주의] AddMsgLog 초기화 안해주면 ThreadRecv() 동작안함
            addMsgLog = addLogListBox;

            //아이디 가져오기
            memberDAO.SearchId(strId);

            //회원 서버연결여부 true로 변경
            UpdateStateConnect(strId, "true");

            ServerConnect();//서버 연결
            RefreshData();  //접속자 목록 불러오기
        }

        //타이머 접속자 목록 계속 새로고침해줘야함
        private void timer_Tick(object sender, EventArgs e)
        {

            if (member.IsConnect == "true")
            {
                RefreshData();
            }
        }

        //커넥트
        private void ServerConnect()
        {
            // 소켓 생성(휴대폰 구매)
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            ipep = new IPEndPoint(IPAddress.Parse(ip), port);

            addLogListBox("서버 접속 시도");
            this.clientSocket.Connect(this.ipep);
            addLogListBox("서버 접속 완료");

            // 서버와 송/수신 스레드 생성
            isRecv = true;
            tRecv = new Thread(new ThreadStart(ThreadRecv));
            tRecv.IsBackground = true;
            tRecv.Start();

            //회원 서버연결여부 true로 변경
            UpdateStateConnect(strId, "true");
        }

        //디스커넥트
        private void DisConnect()
        {
            try
            {
                this.isRecv = false;
                // 클라이언트 소켓 객체가 존재하고, 연결되어있다면
                if (this.clientSocket != null && this.clientSocket.Connected)
                {
                    this.clientSocket.Close();
                }
            }
            catch (Exception ex)
            {
                addLogListBox("DisConnect() Exception : " + ex.Message);
            }
        }

        //채팅 송신 메세지
        private void TxtSendMsg_KeyDown(object sender, KeyEventArgs e)
        {
            if (this.clientSocket != null && this.clientSocket.Connected)
            {
                switch (e.KeyCode)
                {
                    case Keys.Enter:
                        string cmd = "wait";
                        string data = cmd + "|" + member.Id + "|" + TxtSendMsg.Text;
                        NetworkStream ns = new NetworkStream(clientSocket);
                        StreamWriter sw = new StreamWriter(ns);
                        sw.WriteLine(data);
                        sw.Flush();
                        addLogListBox("[" + member.Id + "] > " + TxtSendMsg.Text);
                        TxtSendMsg.Text = "";
                        break;
                }
            }
        }

        //인디언 송신


        //수신 스레드
        private void ThreadRecv()
        {
            NetworkStream ns = new NetworkStream(this.clientSocket);
            StreamReader sr = new StreamReader(ns);

            while (isRecv)
            {
                try
                {
                    string data = sr.ReadLine();
                    string[] dataArr = data.Split(new char[] { '|' });
                    string cmd = dataArr[0];    //wait : waitingRoom
                    string id = dataArr[1]; //보낸이 아이디 또는 Idx
                    string msg = dataArr[2];    //메세지

                    switch (cmd)
                    {
                        case "wait": addLogListBox("[" + id + "] > " + msg); break;
                        case "indianPoker": break;
                        case "cookieRun":
                            if (msg.Equals("start"))
                            {
                                historyDAO.SearchHistory(int.Parse(id));
                                history = historyDAO.history;

                                if (frmMultiCookie == null || frmMultiCookie.IsDisposed)
                                {
                                    frmMultiCookie = new FrmMultiCookie(history.Player1_Id, history.Player2_Id);
                                    frmMultiCookie.ShowDialog();
                                }
                            }
                            break;
                    }
                }
                catch (Exception ex)
                {
                    addLogListBox("ThreadRecv() Exception : " + ex.Message);
                    isRecv = false;
                    clientSocket = null;
                }
            }
            addLogListBox("서버 접속 종료");
        }

        //전체 채팅창
        private void addLogListBox(string log)
        {
            if (lbLog.InvokeRequired)
            {
                Invoke(addMsgLog, new object[] { log });
            }
            else
            {
                lbLog.Items.Add(log);
                lbLog.SelectedIndex = lbLog.Items.Count - 1;
            }
        }

        //접속자 목록 초기화
        private void RefreshData()
        {
            LvConnect.Items.Clear();
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"SELECT [Idx]
                                        ,[Id]
                                        ,[Name]
                                        ,[State]
                                  FROM   [dbo].[MemberTbl]
                                  WHERE  [IsConnect] = 'true'";

                    cmd.CommandText = query;
                    SqlDataReader sr = cmd.ExecuteReader();

                    while (sr.Read())
                    {
                        string[] datas = new string[sr.FieldCount];
                        for (int i = 0; i < datas.Length; i++)
                        {
                            datas[i] = sr.GetValue(i).ToString();
                        }
                        LvConnect.Items.Add(new ListViewItem(datas));
                    }

                    sr.Close();
                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                addLogListBox($"예외발생 : {ex.Message}");
            }
        }

        //Ready
        private void BtnReady(string title)
        {
            matchingTimer.Stop();
            if (title.Equals(TxtIndianPoker.Text))
            {
                BtnIndianReady.BackColor = Color.Red;
                BtnCookieReady.BackColor = Color.DarkOrange;
            }
            else
            {
                BtnIndianReady.BackColor = Color.DarkOrange;
                BtnCookieReady.BackColor = Color.Red;
            }
            // 회원상태 게임명 + Ready로 변경
            memberDAO.member.State = title + " Ready";
            memberDAO.UpdateState();

            CookieReadyMsg();
        }

        //쿠키런 레디 메세지 보내기
        private void CookieReadyMsg()
        {
            string cmd = "cookie";
            string msg = "ready";
            string data = cmd + "|" + member.Id + "|" + msg;
            NetworkStream ns = new NetworkStream(clientSocket);
            StreamWriter sw = new StreamWriter(ns);
            sw.WriteLine(data);
            sw.Flush();
            addLogListBox("[" + member.Id + "] > " + member.State);
        }

        //인디언포커 레디
        private void BtnIndianReady_Click(object sender, EventArgs e)
        {
            BtnReady(TxtIndianPoker.Text);
        }
        
        //쿠키런 레디
        private void BtnCookieReady_Click(object sender, EventArgs e)
        {
            BtnReady(TxtCookieRun.Text);
        }

        //Ready 취소
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            matchingTimer.Stop();
            BtnIndianReady.BackColor = Color.DarkOrange;
            BtnCookieReady.BackColor = Color.DarkOrange;
            memberDAO.member.State = "온라인";
            memberDAO.UpdateState();
        }

        //종료
        private void BtnExit_Click(object sender, EventArgs e)
        {
            UpdateStateConnect(member.Id, "false");
            DisConnect();
            Environment.Exit(0);
            //this.Close();
        }

        //닫기버튼 종료
        private void FrmWaitingRoom_FormClosed(object sender, FormClosedEventArgs e)
        {
            UpdateStateConnect(member.Id, "false");
            DisConnect();
            timer.Stop();
            Environment.Exit(0);
            //this.Close();
        }

        //접속중 회원 isConnect = true 바꾸기
        private void UpdateStateConnect(string id, string isConnect)
        {
            try
            {
                memberDAO.member.Id = id;
                if (isConnect.Equals("true")) memberDAO.member.State = "온라인";
                else memberDAO.member.State = "오프라인";
                memberDAO.UpdateState();
                memberDAO.member.IsConnect = isConnect;
                memberDAO.UpdateConnect();
                member = memberDAO.member;
            }
            catch (Exception ex)
            {
                addLogListBox($"예외발생 : {ex.Message}");
            }
        }

    }
}
