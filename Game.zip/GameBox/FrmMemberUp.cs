﻿using GameBox.Member;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmMemberUp : Form
    {
        MemberDAO mbd = new MemberDAO();
        MemberDTO mto = new MemberDTO();


        string Id;

        public FrmMemberUp(string id)
        {
            this.Id = id;
            InitializeComponent(); 
        }
        private void FrmMemberUp_Load(object sender, EventArgs e)
        {
            mbd.SearchId(Id);
            mto = mbd.member;
            UpInfo_ID.Text = mto.Id;
            UpInfo_PW.Text = mto.Password;
            UpInfo_Name.Text = mto.Name;
            UpInfo_Phone.Text = mto.Phone;



        }
        private void btn_UpInfo_Click(object sender, EventArgs e)
        {

            mbd.member = mto;
            mto.Id = UpInfo_ID.Text;
            mto.Password = UpInfo_PW.Text;
            mto.Name = UpInfo_Name.Text;
            mto.Phone = UpInfo_Phone.Text;
            mbd.isNew = false;
            mbd.SaveData();
        }

    }
}
