﻿using GameBox.DataBase;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmHistoryList : Form
    {
        string gameTitle;

        SqlConnection conn = null;

        public FrmHistoryList(string gameTitle)
        {
            this.gameTitle = gameTitle;
            InitializeComponent();
        }

        private void FrmMemberList_Load(object sender, EventArgs e)
        {
            this.conn = new SqlConnection(Common.ConnString);
            this.conn.Open();

            lv_table.Items.Clear();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = this.conn;
                var query = @"SELECT *
                              FROM [dbo].[GameHistoryTbl] 
                              WHERE [GameTitle] = @GameTitle";

                cmd.CommandText = query;
                cmd.Parameters.AddWithValue("@GameTitle", gameTitle);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string[] datas = new string[reader.FieldCount];

                    for (int i = 0; i < datas.Length; i++)
                        datas[i] = reader.GetValue(i).ToString();

                    lv_table.Items.Add(new ListViewItem(datas));
                }

                reader.Close();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("예외 : " + ex.Message);
            }
        }
    }
}
