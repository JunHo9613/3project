﻿using GameBox.Member;
using System;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmMatching : Form
    {
        int cntTime;
        public string myId, otherId, state;
        MemberDTO my = new MemberDTO();
        MemberDTO other = new MemberDTO();
        MemberDAO memberDAO = new MemberDAO();

        public FrmMatching(string myId, string otherId, string state)
        {
            this.myId = myId;
            this.otherId = otherId;
            this.state = state;
            InitializeComponent();
        }

        private void FrmMatching_Load(object sender, EventArgs e)
        {
            cntTime = 0;
        }

        //준비 상태로 5초 지나면 게임 시작
        private void timer_Tick(object sender, EventArgs e)
        {
            cntTime += 1;

            if (cntTime == 5)
            {
                timer.Stop();

                memberDAO.SearchAll();
                foreach (var member in memberDAO.memberList)
                {
                    if (member.Id.Equals(myId))
                    {
                        my = member;
                    }
                    else if (member.Id.Equals(otherId))
                    {
                        other = member;
                    }
                }

                //나와 상대 모두 접속중이여야 하고, 선택한 게임을 준비 중인 상태여야 한다.
                if(my.State.Equals(state) && my.IsConnect.Equals("true") &&
                    other.State.Equals(state) && other.IsConnect.Equals("true"))
                {
                    //인디언 포커 게임 준비 상태
                    if(state.Equals("인디언 포커 Ready"))
                    {

                    }
                    //쿠키런 게임 준비 상태
                    else if (state.Equals("쿠키런 Ready"))
                    {

                    }
                }
            }
        }
    }
}
