﻿
namespace GameBox
{
    partial class FrmMemberList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lv_table = new System.Windows.Forms.ListView();
            this.column_Idx = new System.Windows.Forms.ColumnHeader();
            this.column_ID = new System.Windows.Forms.ColumnHeader();
            this.column_PW = new System.Windows.Forms.ColumnHeader();
            this.column_Name = new System.Windows.Forms.ColumnHeader();
            this.column_Phone = new System.Windows.Forms.ColumnHeader();
            this.column_Money = new System.Windows.Forms.ColumnHeader();
            this.column_State = new System.Windows.Forms.ColumnHeader();
            this.column_Connect = new System.Windows.Forms.ColumnHeader();
            this.column_RegDate = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // lv_table
            // 
            this.lv_table.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lv_table.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.column_Idx,
            this.column_ID,
            this.column_PW,
            this.column_Name,
            this.column_Phone,
            this.column_Money,
            this.column_State,
            this.column_Connect,
            this.column_RegDate});
            this.lv_table.Font = new System.Drawing.Font("맑은 고딕", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lv_table.FullRowSelect = true;
            this.lv_table.GridLines = true;
            this.lv_table.HideSelection = false;
            this.lv_table.Location = new System.Drawing.Point(33, 35);
            this.lv_table.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lv_table.Name = "lv_table";
            this.lv_table.Size = new System.Drawing.Size(1145, 814);
            this.lv_table.TabIndex = 0;
            this.lv_table.UseCompatibleStateImageBehavior = false;
            this.lv_table.View = System.Windows.Forms.View.Details;
            this.lv_table.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // column_Idx
            // 
            this.column_Idx.Text = "Idx";
            this.column_Idx.Width = 100;
            // 
            // column_ID
            // 
            this.column_ID.Text = "ID";
            this.column_ID.Width = 300;
            // 
            // column_PW
            // 
            this.column_PW.Text = "Password";
            this.column_PW.Width = 250;
            // 
            // column_Name
            // 
            this.column_Name.Text = "Name";
            this.column_Name.Width = 300;
            // 
            // column_Phone
            // 
            this.column_Phone.Text = "Phone";
            this.column_Phone.Width = 300;
            // 
            // column_Money
            // 
            this.column_Money.Text = "Money";
            this.column_Money.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.column_Money.Width = 250;
            // 
            // column_State
            // 
            this.column_State.Text = "State";
            this.column_State.Width = 300;
            // 
            // column_Connect
            // 
            this.column_Connect.Text = "Connect";
            this.column_Connect.Width = 150;
            // 
            // column_RegDate
            // 
            this.column_RegDate.Text = "RegistDate";
            this.column_RegDate.Width = 400;
            // 
            // FrmMemberList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1183, 862);
            this.Controls.Add(this.lv_table);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmMemberList";
            this.Text = "FrmMemberList";
            this.Load += new System.EventHandler(this.FrmMemberList_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lv_table;
        private System.Windows.Forms.ColumnHeader column_Idx;
        private System.Windows.Forms.ColumnHeader column_ID;
        private System.Windows.Forms.ColumnHeader column_PW;
        private System.Windows.Forms.ColumnHeader column_Name;
        private System.Windows.Forms.ColumnHeader column_Phone;
        private System.Windows.Forms.ColumnHeader column_Money;
        private System.Windows.Forms.ColumnHeader column_RegDate;
        private System.Windows.Forms.ColumnHeader column_State;
        private System.Windows.Forms.ColumnHeader column_Connect;
    }
}