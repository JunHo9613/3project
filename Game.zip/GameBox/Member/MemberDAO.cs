﻿using GameBox.DataBase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GameBox.Member
{
    class MemberDAO 
    {
        public DataGridView DgvData { get; set; }
        public ListView LvConnect { get; set; }
        public MemberDTO member { get; set; }
        public List<MemberDTO> memberList = new List<MemberDTO>();
        public bool isNew { get; set; }

        public MemberDAO() 
        { 
            member = new MemberDTO();
            LvConnect = new ListView();
        }

        //회원 추가, 회원정보 수정
        public void SaveData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "";

                    if (isNew == true) // ISNERT
                    {
                        query = @"INSERT INTO [dbo].[MemberTbl]
                                       ([Id]
                                       ,[Password]
                                       ,[Name]
                                       ,[Phone])
                                 VALUES
                                       (@Id
                                       ,@Password
                                       ,@Name
                                       ,@Phone) ";
                    }
                    else // UPDATE
                    {
                        query = @"UPDATE [dbo].[MemberTbl]
                                       SET [Id] = @Id
                                          ,[Password] = @Password
                                          ,[Name] = @Name
                                          ,[Phone] = @Phone
                                     WHERE Idx = @Idx ";
                    }
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Id", member.Id);
                    cmd.Parameters.AddWithValue("@Password", member.Password);
                    cmd.Parameters.AddWithValue("@Name", member.Name);
                    cmd.Parameters.AddWithValue("@Phone", member.Phone);

                    if (isNew == false) // Update 일때만 처리
                    {
                        cmd.Parameters.AddWithValue("@Idx", member.Idx);
                    }

                    var result = cmd.ExecuteNonQuery();
                    if (result == 1)
                    {
                        MessageBox.Show("저장 성공", "저장",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("저장 실패", "저장",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"MemberDAO SaveData 예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //소지금 수정
        public void UpdateMoney()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[MemberTbl]
                                       SET [Money] = @Money
                                     WHERE Idx = @Idx ";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Money", member.Money);
                    cmd.Parameters.AddWithValue("@Idx", member.Idx);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"MemberDAO UpdateMoney 예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //상태 수정
        public void UpdateState()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[MemberTbl]
                                       SET [State] = @State
                                     WHERE Idx = @Idx ";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@State", member.State);
                    cmd.Parameters.AddWithValue("@Idx", member.Idx);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"MemberDAO UpdateReady 예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //Connect 수정
        public void UpdateConnect()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[MemberTbl]
                                       SET [IsConnect] = @IsConnect
                                     WHERE Idx = @Idx ";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@IsConnect", member.IsConnect);
                    cmd.Parameters.AddWithValue("@Idx", member.Idx);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"MemberDAO UpdateConnect 예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //ID로 회원찾기
        public void SearchId(string id)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"SELECT [Idx]
                                        ,[Id]
                                        ,[Password]
                                        ,[Name]
                                        ,[Phone]
                                        ,[Money]
                                        ,[State]
                                        ,[IsConnect]
                                        ,[RegDate]
                                  FROM   [dbo].[MemberTbl]
                                  WHERE  [Id] = @Id ";

                    cmd.CommandText = query;
                    cmd.Parameters.AddWithValue("@Id", id);

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];
                    if (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            Console.WriteLine(datas[i] + "/");
                            datas[i] = reader.GetValue(i).ToString();
                        }

                        member.Idx = int.Parse(datas[0]);
                        member.Id = datas[1];
                        member.Password = datas[2];
                        member.Name = datas[3];
                        member.Phone = datas[4];
                        member.Money = int.Parse(datas[5]);
                        member.State = datas[6];
                        member.IsConnect = datas[7];
                        member.RegDate = datas[8];
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //전체 회원 찾기
        public void SearchAll()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"SELECT *
                                  FROM [dbo].[MemberTbl] ";
                    cmd.CommandText = query;

                    SqlDataReader sr = cmd.ExecuteReader();
                    string[] datas = new string[sr.FieldCount];

                    memberList.Clear();
                    while (sr.Read())
                    {
                        for (int i = 0; i < sr.FieldCount; i++)
                        {
                            datas[i] = sr.GetValue(i).ToString();
                        }

                        MemberDTO member = new MemberDTO();
                        member.Idx = int.Parse(datas[0]);
                        member.Id = datas[1];
                        member.Password = datas[2];
                        member.Name = datas[3];
                        member.Phone = datas[4];
                        member.Money = int.Parse(datas[5]);
                        member.State = datas[6];
                        member.IsConnect = datas[7];
                        member.RegDate = datas[8];
                        memberList.Add(member);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"MemberDAO SearchAll() 예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        //접속한 회원 찾기
        public void SearchConnect()
        {
            LvConnect.Items.Clear();
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"SELECT [Idx]
                                        ,[Id]
                                        ,[Name]
                                        ,[State]
                                  FROM   [dbo].[MemberTbl]
                                  WHERE  [IsConnect] = 'true'";

                    cmd.CommandText = query;
                    SqlDataReader sr = cmd.ExecuteReader();

                    while (sr.Read())
                    {
                        string[] datas = new string[sr.FieldCount];
                        for (int i = 0; i < datas.Length; i++)
                        {
                            datas[i] = sr.GetValue(i).ToString();
                        }
                        LvConnect.Items.Add(new ListViewItem(datas));
                    }

                    sr.Close();
                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //회원 삭제
        public void Delete()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "";

                    query = "DELETE FROM [dbo].[membertbl] " +
                            " WHERE [Idx] = @Idx ";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Idx", member.Idx);
                    var result = cmd.ExecuteNonQuery();
                    if (result == 1)
                    {
                        MessageBox.Show("삭제 성공", "삭제", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("삭제 실패", "삭제", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"예외발생 : {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
