﻿using GameBox.Member;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmLogin : Form
    {
        public string strId { get; set; }
        MemberDAO memberDAO = new MemberDAO();

        public FrmLogin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            strId = ""; 

            //MessageBox.Show("로그인 처리!");
            if (string.IsNullOrEmpty(TxtId.Text) || string.IsNullOrEmpty(TxtPassword.Text))
            {
                MessageBox.Show("아이디/패스워드를 입력하세요!", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //아이디 있는지 확인
            memberDAO.SearchId(TxtId.Text);
            strId = memberDAO.member.Id;

            if (string.IsNullOrEmpty(strId))
            {
                MessageBox.Show("접속실패", "로그인실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if(TxtId.Text.Equals(memberDAO.member.Id) && TxtPassword.Text.Equals(memberDAO.member.Password))
            {
                MessageBox.Show(this, "접속성공", "로그인성공", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ((FrmMain)this.Owner).strId = strId;
                this.Close();
            }
            else
            {
                MessageBox.Show(this, "아이디 또는 비밀번호를 다시 확인해주세요.", "로그인성공", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void BtnFind_Click(object sender, EventArgs e)
        {
            FrmFind frmFind = new FrmFind();
            frmFind.ShowDialog();
        }

        private void BtnJoin_Click(object sender, EventArgs e)
        {
            FrmJoin frm = new FrmJoin();
            frm.ShowDialog();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "종료하시겠습니까?", "종료", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }
    }
}
