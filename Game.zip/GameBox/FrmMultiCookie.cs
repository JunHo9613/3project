﻿using GameBox.Member;
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace GameBox
{
    public partial class FrmMultiCookie : Form
    {
        FrmCookieRun frmCookie = null;

        MemberDTO my = new MemberDTO();
        MemberDTO other = new MemberDTO();
        MemberDAO memberDAO = new MemberDAO();

        const string ip = "127.0.0.1";      //IP
        const int port = 9000;              //PORT

        public FrmMultiCookie(string myId, string otherId)
        {
            memberDAO.SearchId(myId);
            my = memberDAO.member;
            memberDAO.SearchId(otherId);
            other = memberDAO.member;

            InitializeComponent();
        }

        private void InitMnu()
        {
            MnuMyScore.Text = "0";
            MnuStartMoneyValue.Text = my.Money.ToString();
            MnuLastMoneyValue.Text = "0";
            MnuWinnerIdValue.Text = "???";
            MnuWinnerScoreValue.Text = "0";
            MnuResultValue.Text = "-";
        }

        private void makeFrmCookie()
        {
            frmCookie = new FrmCookieRun();
            frmCookie.FormBorderStyle = FormBorderStyle.None;
            frmCookie.ControlBox = false;
            frmCookie.MaximizeBox = false;
            frmCookie.MinimizeBox = false;
            frmCookie.ShowIcon = false;
            frmCookie.ShowInTaskbar = false;
            frmCookie.Location = new System.Drawing.Point(50, 50);
            frmCookie.Owner = this;
            frmCookie.ShowDialog();
        }

        private void FrmMultiCookie_Load(object sender, EventArgs e)
        {
            if(frmCookie == null || frmCookie.IsDisposed)
            {
                InitMnu();
                makeFrmCookie();
            }
        }
    }
}
                                                                           